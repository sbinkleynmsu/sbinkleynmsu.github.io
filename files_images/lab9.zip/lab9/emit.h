//Shea Binkley
//CS370: Compilers - Dr. Cooper
//11/5/2023
//Lab9:  emitter.h file for compliers with MIPS, set of fucntions to create proper MIPS code and place it in appropriate open file
    //input: nodes from yacc file and an algol-c test file
    //output: assembly code that mips can be used to run assembly code from asm file, used for emit.c file
//lab9 changes: entire file new for lab9, inputted functions to handle nodes from yacc

#ifndef EMIT_H
#define EMIT_H
#include "ast.h"
#include "symtable.h"

#define WSIZE 4
#define LOG_WSIZE 2

//have to be used
void EMIT_GLOBALS(ASTnode *p, FILE *fp);
void EMIT_STRINGS(ASTnode *p, FILE *fp);
void EMIT(ASTnode *p, FILE *fp);

#endif