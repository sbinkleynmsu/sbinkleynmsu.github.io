//Shea Binkley
//CS370: Compilers - Dr. Cooper
//11/5/2023
//Lab9:  emitter file for compliers with MIPS, set of fucntions to create proper MIPS code and place it in appropriate open file
    //input: nodes from yacc file and an algol-c test file and emit.h file
    //output: assembly code that mips can be used to run assembly code from asm file
//lab9 changes: entire file new for lab9, inputted functions to handle nodes from yacc

#include "emit.h"
#include <string.h>
#include<stdlib.h>
int GLABEL = 0;
char * CurrentFunc = NULL;
char * CreateLabel();

//in file prototypes defined in this file and not used otherwise
//optional to be used
void emit_ast(ASTnode *p, FILE *fp);
void emit_function_dec(ASTnode *p, FILE *fp);
void emit_write(ASTnode *p, FILE *fp);
void emit_expr(ASTnode *p, FILE *fp);
void emit_var(ASTnode *p, FILE *fp);
void emit_return(ASTnode *p, FILE *fp);
void emit_call(ASTnode *p, FILE *fp);
void emit_param(ASTnode *p, FILE *fp);
void emit_assign(ASTnode *p, FILE *fp);


//PRE: PTR to ASTnode
//POST: ALl mips code directly and through helper fucntions prints into the file via fp
void EMIT(ASTnode *p, FILE * fp){
    fprintf(fp, "#Compliers MIPS code\n");
    fprintf(fp, "\n.data \n");
    EMIT_STRINGS(p, fp);
    fprintf(fp, "\n.align 2 \n"); 
    EMIT_GLOBALS(p, fp);
    fprintf(fp, "\n.text\n");
    fprintf(fp, "\n.globl main\n");
    emit_ast(p, fp);
}//end of EMIT

// PRE:  PTR to top of AST, and FILE ptr to print to 
// POST:  prints MIPS based  global variables into file 
void EMIT_GLOBALS(ASTnode* p, FILE *fp){
    //global variable is defined as a node type of A_VARDEC 
    //added another char PTR for label in AST.h
    if (p == NULL) return;
    if((p->nodetype == A_VARDEC) && (p->symbol->level == 0)){//printing wrong size if all decalred on same line
        fprintf(fp, "%s:    .space     %d # global variable\n", p->symbol->name, p->symbol->mysize*WSIZE); 
    }//end of if
    EMIT_GLOBALS(p->s1, fp);
    EMIT_GLOBALS(p->s2, fp);
    
}// end of emit globals

// PRE:  PTR to top of AST, and FILE ptr to print to 
// POST:  Adds a label into the AST for use string in write statements 
// POST:  prints MIPS based  string  into file 
void EMIT_STRINGS(ASTnode* p, FILE *fp){
    if(p == NULL) return;
    if((p->nodetype == A_WRITE) && (p->name != NULL)){
        p->label = CreateLabel();
        fprintf(fp, "%s:    .asciiz     %s\n", p->label, p->name);
    }// end of if
    EMIT_STRINGS(p->s1, fp);
    EMIT_STRINGS(p->s2, fp);  
}// end of emit strings 

//PRE: global varible GLABEL
//POST: holds value to be used when printing labels for global variables in form of "_L#"
char * CreateLabel()
{    char s[100];
     char * label;
     sprintf(s,"_L%d",GLABEL++);
     label=strdup(s);
     return(label); 
}// end of createLabel

//Pre: possible label, command, comment
//Post: formatted output to the file
void emit(FILE *fp, char *label, char* command, char * comment){
    if (strcmp("", comment)==0)
        if(strcmp("", label)==0)
            fprintf(fp,"\t%s\t\t\n", command);
        else
            fprintf(fp, "%s:\t%s\t\t\n",label,command);
    else
        if(strcmp("",label)==0)
            fprintf(fp,"\t%s\t\t# %s\n", command, comment);
        else
            fprintf(fp,"%s:\t%s\t\t# %s\n", label, command, comment);
}//end of emit 


//Pre:PTR to a A_FUNDEC node
//Post: MIPS code for the fucntion using emit_ast as a helper
void emit_function_dec(ASTnode *p, FILE *fp){
    CurrentFunc = p->name;
    char s[100];
    int t = 0;
    //print out the function label
    emit(fp,p->name,""," START OF FUNCTION");
    fprintf(fp,"\n");
    sprintf(s, "subu $a0, $sp, %d", p->symbol->offset*WSIZE);
    emit(fp, "", s, " # adjust the stack for function setup");
    emit(fp,"","sw $sp, ($a0)", " # remmeber old SP");
    emit(fp,"","sw $ra, 4($a0)", " # remmeber current return address");
    emit(fp,"","move $sp, $a0", " # adjust the stack pointer");
    fprintf(fp,"\n");
    fprintf(fp,"\n");

    //handeling storeing args in t registers
    ASTnode * Args = p->s1;
    while(Args != NULL){
        //process the node
        sprintf(s,"","sw $t%d, %d($sp)", t++, Args->symbol->offset*WSIZE);
        emit(fp, "", s, " # ");
        Args = Args ->s1;
    } //end of while for args 

    emit_param(p,fp); //calls for param
    
    emit_ast(p->s2,fp); //calls for compound statement  
    
    emit_return(NULL,fp); //calls for return
}// end of emit_function_dec

//Pre: PTR to a A_PARAM node
//Post: MIPS code for parameters used in emit_func_dec as a helper
//shoudlbe called in emit_dec after stack carve out 
void emit_param(ASTnode *p, FILE *fp){
    char s[100];
    ASTnode * ParamPointer =p->s1;
    int temp = 0;
    while(ParamPointer != NULL){ 
        sprintf(s,"sw $t%d, %d($sp)",temp++,ParamPointer->symbol->offset*WSIZE);
        emit(fp,"", s," # Load temp variable int formal paramter");
        ParamPointer = ParamPointer->s1;
    }//end of paramlist while loop
}//end of emit_param

//Pre: PTR to a A_CALL node
//Post: MIPS code for calling a function with arguments 
void emit_call(ASTnode *p, FILE *fp){
    char s[100];
    char t_[8];
    int t =0;
    emit(fp,"", ""," # Setting Up Function Call");
    emit(fp,"", ""," # evaluate  Function Parameters");
    
    //fix fix fix 
    //run through args and store them in spot of t_
    //store results in t_ before calling
    //no more than 8 check for barf
    ASTnode * Args = p->s1;
    while(Args != NULL){ 
        emit_expr(Args->s1,fp); //expression
        sprintf(s,"sw $a0, %d($sp)",Args->symbol->offset*WSIZE);
        emit(fp,"", s," # Load temp variable int formal paramter");
        Args = Args->s2; //arglist    
    }//end of args while loop
    fprintf(fp,"\n");

    ASTnode * Argslist = p->s1;
    while(Argslist != NULL && t < 8){
        emit(fp,"",""," # place   Parameters into T registers");
        sprintf(s,"lw $a0, %d($sp)",Argslist->symbol->offset*WSIZE);
        emit(fp,"", s," # pull out stored  Arg");
        sprintf(s,"move $t%d, $a0",t++);
        emit(fp,"",s," # move arg in temp");
        Argslist = Argslist -> s2;
    }//end of while for arglist
    fprintf(fp,"\n");

    sprintf(s,"jal %s",p->name);
    emit(fp,"",s," # call the function");
    fprintf(fp,"\n");
}//end of emit_call


//Pre: null or a return node
//Post: MIPS code for a return using emit_expr to either print an expression or null
void emit_return(ASTnode *p, FILE *fp){
    char s[100];
    //return has no expression
    if(p == NULL || p->s1 == NULL){
        emit(fp,"","li $a0, 0"," # RETURN has no specified value set to 0");

    }//end if blank return 
    //else return returns an expression
    else{
        emit_expr(p->s1,fp);
    }// end else return expr
    //ra and sp 
    //syscall 10 if main otherwise jr
    emit(fp,"", "lw $ra, 4($sp)", " # restore RA");
    emit(fp,"", "lw $sp, ($sp)"," # restore SP");

    //if function is main
    if(strcmp(CurrentFunc,"main") == 0){
        fprintf(fp,"\n");
        emit(fp,"", "li $v0, 10"," # leave MAIN program");
        emit(fp,"", "syscall"," # leave main");
    }//end if strcmp
    //else function is not main
    else{
        fprintf(fp,"\n");
        emit(fp,"", "jr $ra"," # return to caller");
    }//end else not main
    fprintf(fp,"\n\n");
}//end of emit_return


//PRE: PTR to a write node
//POST: mips code to preform write
void emit_write(ASTnode *p, FILE *fp){
    // two flavors of write: string and expression
    char s[100];
    //if its a string
    if(p->name != NULL){
        emit(fp,"","li $v0, 4","#print a string");
        sprintf(s,"la $a0, %s",p->label);
        emit(fp,"",s,"#print fetch string location");
        emit(fp,"","syscall","");
        fprintf(fp,"\n\n");
    }//end if string
    //else its an expression
    else{
        emit_expr(p->s1,fp);
        emit(fp,"","li $v0 1"," # print the number");
        emit(fp,"","syscall"," # system call for print number");
        fprintf(fp,"\n\n"); 
    }//end else expr
}//end of emit_write

//PRE: PTR to a read var
//POST: mips code to generate location of var and read it in
void emit_read(ASTnode *p, FILE *fp){
    emit_var(p->s1, fp); //$a0 is the memory location
    emit(fp,"","li $v0, 5", " # read a number from input");
    emit(fp,"","syscall", " # reading a number");
    emit(fp,"","sw $v0, ($a0)", " # store the read into a mem location");
    fprintf(fp,"\n");
}//end of emit_read

//PRE: PTR to A_VAR
//POST:$a0 will be the memory location of the variable
//vars are either global or local
//array or not
//for global, the start point is where the label is located
//for local it is stack pointer plus offset /*wsize
//for array we have to add on the internal offset to these values
void emit_var(ASTnode *p, FILE *fp){
    char s[100];

    //globals have level 0
    if(p->symbol->level == 0){
        //if global var is an array
        if(p->s1 != NULL){
            emit_expr(p->s1,fp);
            //store a0 in temp varible 
            //multiply by 4 of shift logical f2
            //add on stack pointer + offset 
            emit(fp,"","move $a1, $a0"," # VAR copy index array in a1");
            sprintf(s,"sll $a1 $a1 %d",LOG_WSIZE);
            emit(fp,"",s," # multiply the index by wordszie via SLL");
	        emit(fp,"","move $a0 $sp"," # VAR local make a copy of stackpointe");
            sprintf(s,"la $a0, %s", p->name);
            emit(fp,"",s," # EMIT Var global variable");
	        emit(fp,"","add $a0 $a0 $a1"," # VAR array add internal offset");

        }//end if global array
        //else regular var
        else{
            sprintf(s,"la $a0, %s",p->name);
            emit(fp,"",s,"#EMIT var global variable");
        }//end else reg var
        
    }//end of global vars 

    //else its local
    else{
        // if local var is an array
        if(p->s1 != NULL){
            emit_expr(p->s1,fp);
            //store a0 in temo varible 
            //mutiple by 4 of shift logical f2
            //add on stack pointer + offset 
            emit(fp,"","move $a1, $a0"," # VAR copy index array in a1");
            sprintf(s,"sll $a1 $a1 %d",LOG_WSIZE);
            emit(fp,"",s," # multiply the index by wordszie via SLL");
	        emit(fp,"","move $a0 $sp"," # VAR local make a copy of stackpointe");
            sprintf(s,"addi $a0 $a0 %d", p->symbol->offset*WSIZE);
	        emit(fp,"",s," # VAR local stack pointer plus offset");
	        emit(fp,"","add $a0 $a0 $a1"," # VAR array add internal offset");
	        
        }// end if local array
        // else its regular var
        else{
            //$a0 needs to $sp + offset *wsize
            emit(fp,"","move  $a0, $sp"," # VAR local make a copy of stackpointer");
            sprintf(s,"addi $a0 $a0 %d", p->symbol->offset*WSIZE);
            emit(fp,"",s," # add stack pointer to $a0");
        }// end of local reg var       
    }//end of local vars
}// end of emit_var


//Pre: PTR of an assignmnet expression of emit_expr
//Post: mips code to store rhs and then store lhs into rhs and store rhs value into memory
void emit_assign(ASTnode *p, FILE *fp){
    // emit_the expresson of assign store it temporarily emit the Left hand side into $a0 
    // retrieve stored value into $a1 store $a1 into ($a0)
    char s[100];
    emit_expr(p->s2,fp); 
    sprintf(s, "sw $a0 %d($sp)", p->symbol->offset*WSIZE);
    emit(fp,"",s," # Assign store RHS temporarily");
    emit_var(p->s1,fp);
    //$a0 will be the memory location of the variable
    sprintf(s, "lw $a1 %d($sp)", p->symbol->offset*WSIZE);
	emit(fp,"",s," # Assign get RHS temporarily");
	emit(fp,"","sw $a1 ($a0)"," # Assign place RHS into memory");
    fprintf(fp,"\n");
    fprintf(fp,"\n");
}//end of emit_assign

//Pre: PTR to a A_IFSTMT and A_IFBODY nodes
//Post: mips code to jump to labels of if statement and emit_expr
void emit_if(ASTnode *p, FILE *fp){
    char s[100];
    char * L0, *L1;
    L0 = CreateLabel();
    L1 = CreateLabel();
    emit_expr(p->s1, fp);
    sprintf(s,"beq $a0 $0 %s",L0);
    emit(fp,"",s," # if decision\n");
    fprintf(fp,"\t\t#  the positive portion of IF\n");
    emit_ast(p->s2->s1,fp); //
    sprintf(s,"j %s", L1);
    emit(fp,"",s," # go to exit");
    emit(fp,L0,"", " # else ");
    fprintf(fp,"\t\t#  the negative  portion of IF if there is an else\n\t\t#  otherwise just these lines\n");
    emit_ast(p->s2->s2,fp);
    emit(fp,L1,"", " # end of if");

}//end of emit_if


//Pre: PTR to a A_WHIILE node
//Post:  mips code to jump to labels of while statement using emit_ast as helper
void emit_while(ASTnode *p, FILE *fp){
    char s[100];
    char *L0, *L1;
    //L1 = gen label 
    L0 = CreateLabel();
    //L2 = gen Label 
    L1 = CreateLabel();
    emit(fp,L0,""," # WHILE TOP target ");
    emit_expr(p->s1, fp);
    sprintf(s,"beq $a0 $0 %s", L1);
    emit(fp,"",s," # WHILE branch out");
    emit_ast(p->s2,fp);
    sprintf(s,"j %s", L0);
    emit(fp,"",s," # WHILE Jump back");
    emit(fp,L1,"", " # end of while");
}//end of emit_while


//PRE: PTR to an expression tree componennt (A_EXPR, A_NUM, A_CALL, A_VAR, A_TORF, A_NOT)
//POST: $a0 will have the vlaue set by the generated mips
void emit_expr(ASTnode *p, FILE *fp){
    char s[100];
    if(p==NULL){
        printf("illegal use of EMIT_EXPR with NULL pointer \n");
        exit(1);
    }//end of if null pointer
    switch(p->nodetype){
        case A_TORF:
            case A_NUM: sprintf(s,"li $a0, %d",p->value);
                        emit(fp,"",s," # expression is a constant");
                        return;
                        break;

        //emit var takes PTR to VAR 
        //exits with $a0 as the address of  where VAR lives 
        //VAR can be an array or not-- The algorithm is 
        case A_VAR:     emit_var(p,fp); //$a0 is the location
                        emit(fp,"","lw $a0, ($a0)","#expression is a var, get value");
                        return;
                        break;
                    
        case A_CALL:    emit_call(p,fp);
                        return;
                        break;
        
        //operators 
        case A_EXPR:    emit_expr(p->s1,fp);
                        if(p->s2 != NULL){
                            sprintf(s,"sw $a0, %d($sp)", p->symbol->offset*WSIZE);
                            emit(fp,"",s," # expression store LHS temporary");
                            emit_expr(p->s2,fp); 
                            emit(fp,"","move $a1, $a0", " # right hand side needs to be a1");
                            sprintf(s,"lw $a0, %d($sp)", p->symbol->offset*WSIZE);
                            emit(fp,"",s," # expression restore LHS temporary");
                        }// end of if to p->s2 expression list
                        switch(p -> operator){
                            case A_MINUS:   emit(fp,"", "sub $a0, $a0, $a1"," # EXPR ADD");
                                            break;

                            case A_PLUS:    emit(fp,"", "add $a0, $a0, $a1"," # EXPR SUB");;
                                            break;

                            case A_MULTIPLY:emit(fp,"", "mult $a0, $a1"," # EXPR MULT");
                                            emit(fp,"", "mflo $a0"," # EXPR MULT");
                                            break;

                            case A_DIVIDE:  emit(fp,"", "div $a0, $a1"," # EXPR DIV");
                                            emit(fp,"", "mflo $a0"," # EXPR DIV");
                                            break;

                            case A_LE:      emit(fp,"", "add $a1 ,$a1, 1"," # EXPR LE add one to do compare");
                                            emit(fp,"", "slt $a0"," # EXPR LE");
                                            emit(fp,"", "slt $a0, $a0, $a1"," # EXPR LESSThan");
                                            break;

                            case A_LESS:    emit(fp,"", "slt $a0, $a0, $a1"," # EXPR LESSThan");
                                            break;

                            case A_GREAT:   emit(fp,"", "slt $a0, $a1, $a0"," # EXPR Greaterthan");
                                            break;

                            case A_GE:      emit(fp,"", "add $a1 ,$a1, 1"," # EXPR  ADD GE");
                                            emit(fp,"", "slt $a0, $a1, $a0"," # EXPR Greaterthan");
                                            break;

                            case A_EQ:      emit(fp,"", "slt $t2 ,$a0, $a1"," # EXPR EQUAL");
                                            emit(fp,"", "slt $t3 ,$a1, $a0"," # EXPR EQUAL");
                                            emit(fp,"", "nor $a0 ,$t2, $t3"," # EXPR EQUAL");
                                            emit(fp,"", "andi $a0, 1"," # EXPR EQUAL");
                                            break;

                            case A_NE:      emit(fp,"", "slt $t2 ,$a0, $a1"," # EXPR EQUAL");
                                            emit(fp,"", "slt $t3 ,$a1, $a0"," # EXPR EQUAL");
                                            emit(fp,"", "or $a0 ,$t2, $t3"," # EXPR EQUAL");
                                            break;

                            case A_OR :     emit(fp, "", "or $t1, $a0, $a1", " # EXPR OR");
                                            break;

                            case A_AND :    emit(fp, "", "and $t0, $a0, $a1", " # EXPR AND");
                                            break;

                            case A_NOT:     emit(fp,"", "or $a0, $a0, $zero"," # EXPR NOT");
                                            emit(fp,"", "slti $a0 ,$a0, 1"," # EXPR NOT");
                                            break;
                                         
                            default: printf("Unknown operator in A_EXPR ASTPRINT\n");
                                     printf("EXIT\n ");
                                     exit(1);
                        }//end of switch

                        return;
                        break;
         
        default: printf("emit_expr base case not known %d\n", p->nodetype);
        exit(1);
    }//end of switch for operators
}//end of emit_expr

//PRE: PTR to astnode
//POST: main dirver for waalking our AST tree to produce mips code in the file
void emit_ast(ASTnode *p, FILE *fp){
    if(p == NULL) return;
    switch (p->nodetype){
        case A_DEC_LIST:    emit_ast(p->s1, fp);
                            emit_ast(p->s2, fp);
                            break;

        case A_VARDEC:      emit_ast(p->s1, fp);
                            emit_ast(p->s2, fp);
                            break;

        case A_FUNDEC:      emit_function_dec(p,fp);
                            break;

        case A_PARAM:       emit_param(p,fp);
                            break;
                    
        case A_COMP:        emit_ast(p->s1, fp);
                            emit_ast(p->s2, fp);
                            break;

        case A_STMT_LIST:   emit_ast(p->s1, fp);
                            emit_ast(p->s2, fp);
                            break;

        case A_WRITE:       emit_write(p, fp);
                            break;

        case A_READ:        emit_read(p, fp);
                            break;

        case A_ASSIGN_STMT: emit_assign(p,fp);
                            break;

        case A_ARGS:        emit_call(p->s1,fp);
                            break;

        case A_EXPR:        emit_expr(p,fp);
                            break;

        case A_WHILE:       emit_while(p,fp);
                            break;

        case A_EXPR_STMT:   emit_ast(p->s1,fp);
                            break;  

        case A_RETURN:      emit_return(p,fp);
                            break;

        case A_IFSTMT:      emit_if(p,fp);
                            break;


        default: printf("emit_ast() unknown nodetype %d \n", p->nodetype);
                 printf("fix fix fix\n");
                 exit(1);
    }// end of switch node type
}// end of emit ast