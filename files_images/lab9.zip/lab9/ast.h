/*   Shea Binkley
        CS370: Compilers - Dr. Cooper
        11/5/2023
        Lab9: lab9 ast.h file
    	        input: ast nodes 
    	        output: defines node types that are implemented in ast.c for creating of tree
    	lab9 changes: no chnages made for lab9




 Abstract syntax tree code


 Header file   
 Shaun Cooper January 2022

*/

#include<stdio.h>
#include<malloc.h>

#ifndef AST_H
#define AST_H
extern int mydebug;

/* define the enumerated types for the AST.  THis is used to tell us what 
sort of production rule we came across */

enum ASTtype {
   A_PROGRAM, //program
   A_VARDEC, //variable declaration
   A_DEC_LIST, //declaration list
   A_FUNDEC, //function declaration
   A_STMT_LIST, //statement list
   A_EXPR, //expression
   A_COMP, //compound statement
   A_NUM, //number
   A_WRITE, //write
   A_READ, //read
   A_VAR, //variable 
   A_CALL, //call statement
   A_TORF, //true or false value
   A_PARAM, //parameters of function
   A_NOT, //not function
   A_ASSIGN_STMT, //assignment statement
   A_IFBODY, //body of if statement
   A_IFSTMT, //if statement
   A_ARGS, //argument list
   A_WHILE, //while
   A_RETURN, //return
   A_EXPR_STMT //expression statement

};

enum DataTypes {
   A_UNKNOWN,        // unknown for var dec
   A_INTTYPE,        //int
   A_VOIDTYPE,       //void
   A_BOOLEANTYPE     //boolean

};

enum OPERATORS {
   A_PLUS, A_MINUS, A_TIMES, A_AND, A_OR, A_LE, A_LESS, A_GREAT, A_GE, A_EQ, A_NE,
   A_DIVIDE, A_MULTIPLY, A_TERM, 
};

/* define a type AST node which will hold pointers to AST structs that will
   allow us to represent the parsed code 
*/
typedef struct ASTnodetype
{
     enum ASTtype nodetype;
     enum OPERATORS operator;
     enum DataTypes datatype;
     char * name;
     char * label;
     int value; //added value 
     struct ASTnodetype *s1,*s2 ; /* used for holding IF and WHILE components -- not very descriptive */
     struct SymbTab *symbol;
} ASTnode;


/* uses malloc to create an ASTnode and passes back the heap address of the newley created node */
ASTnode *ASTCreateNode(enum ASTtype mytype);

//print out spaces count
void PT(int howmany);

ASTnode *program; // pointer to the tree

/*  Print out the abstract syntax tree */
void ASTprint(int level,ASTnode *p);

#endif // of AST_H
