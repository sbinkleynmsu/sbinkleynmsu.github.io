/*   
        Shea Binkley
        CS370: Compilers - Dr. Cooper
        11/5/2023
        Lab9: lab9 final compiler ast.c file which handles creating a tree using nodes defined in ast.h
    	        input: symbol table, yacc, and lex files to create tree of nodes
    	        output: tree that sorts through nodes
    	lab9 changes: no chnages made for lab9



    Abstract syntax tree code

    This code is used to define an AST node, 
    routine for printing out the AST
    defining an enumerated nodetype so we can figure out what we need to
    do with this.  The ENUM is basically going to be every non-terminal
    and terminal in our language.

    Shaun Cooper February 2023

*/

#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include "symtable.h"
#include "ast.h" 




/* uses malloc to create an ASTnode and passes back the heap address of the newley created node */
// PRE: inputted node from memory
// POST: a new ASTNode with a type and pointers
ASTnode *ASTCreateNode(enum ASTtype mytype)
{
    ASTnode *p;
    if (mydebug) fprintf(stderr,"Creating AST Node \n");
    p=(ASTnode *)malloc(sizeof(ASTnode));
    p->nodetype=mytype;
    p->s1=NULL;
    p->s2=NULL;
    p->value=0; //intialized value to 0
    return(p);
}

/*  Helper function to print tabbing */
//PRE: given a postive number 
//POST: print that number of spaces
void PT(int howmany)
{
	 for(int i = 0; i< howmany; i++){
        printf(" ");
     }
}

// PRE:  a Data Type
// POST:  a character string for that type to print nicely -- caller does final output
char * DataTypeToString(enum DataTypes mydatatype){
    switch (mydatatype) {
            case A_INTTYPE:  return ("int");
                             break;
            case A_VOIDTYPE:  return ("void");
                             break;
            case A_BOOLEANTYPE:  return ("boolean");
                             break;         
            
           default: printf("Unknown type in DataTypeToString\n");
                     exit(1);
      } //of switch
}// of DataTypeToString()

//PRE: pointer to an AST tree
//POST: print to screen formatted tree output
/*  Print out the abstract syntax tree */
void ASTprint(int level,ASTnode *p)
{
   int i;
   if (p == NULL ) return;

    // when here p is not NULL
   switch (p->nodetype) {
        //comes from program
        case A_DEC_LIST: 
                         ASTprint(level, p->s1); //vardec
                         ASTprint(level, p->s2); //fundec
                         break;

        case A_TORF : PT(level);
                      if(p->value > 0)
                        printf("TRUE\n");
                      else          
                        printf("FALSE\n");
                      break;

        case A_NUM:      PT(level);
                         printf("NUM with value %d\n", p->value);
                         break;

        //comes from vardec
        case A_VAR:      PT(level);
                         // print offset and level of a varible
                         printf("VAR with name %s with offset %d level %d\n", p->name, p->symbol->offset, p->symbol->level);
                         //if value of var equals -1, var has an expression printed inside brackets
                         if(p-> value == -1){
                            PT(level+1);
                            printf("[\n");
                            ASTprint(level+2,p->s1); //expression
                            PT(level+1);
                            printf("]\n"); 
                         }//end if
                         break;

        //comes from declaration
        case A_VARDEC :  PT(level);
                         printf("VAR ");
                         printf("%s ", DataTypeToString(p->datatype));
                         printf(" %s",p->name);
                         //if value of variable declartion is greater than 0, variable is an array (defined in yacc)
                         if (p->value > 0)
                            printf("[%d]",p->value);
                         // print offset and level of variable dec
                         printf(" with offset %d level %d", p->symbol->offset, p->symbol->level);
                         printf("\n");
		                 ASTprint(level,p->s1);  //varlist
                         ASTprint(level,p->s2);  //var
                         break;

        //comes from declaration
        case A_FUNDEC : PT(level);
                        printf("Function ");
                        printf("%s ", DataTypeToString(p->datatype));
                        printf(" %s",p->name);
                         // print offset of function
                        printf(" with size %d", p->symbol->offset);
                        //if function has no parameters, the function's parameter is (void)
                        if(p->s1 == NULL){
                            printf(" (void)");
                            printf("\n");
                        }//end if
                        //else the function has parameters
                        else{
                            printf("\n");
                            printf("(\n");
		                    ASTprint(level+1,p->s1); //parameters
                            printf(")\n");
                        }//end else
                        ASTprint(level+1,p->s2); //compound
                        break;

        //comes from fun dec
        case A_PARAM : PT(level); 
                       printf("parameter ");
                       printf("%s ", DataTypeToString(p->datatype));
                       printf(" %s",p->name);
                       if (p->value == -1)
                            printf("[]");
                       // print offset and level of parameter
                       printf(" with offset %d level %d", p->symbol->offset, p->symbol->level);
                       printf("\n");
                       ASTprint(level,p->s1); //paramlist
                       break;

        //comes from fundec
        case A_COMP : PT(level);
                      printf("BEGIN\n");
                      ASTprint(level+1,p->s1); //local vars
                      ASTprint(level+1,p->s2); //statemnt list
                      PT(level);
                      printf("END\n");
                      break; 

        //comes from compound
        case A_STMT_LIST:
                         ASTprint(level, p->s1); //statement
                         ASTprint(level, p->s2); //statement list
                         break;

        //comes from factor, which comes from term            
        case A_CALL : PT(level);
                      printf("CALL %s\n", p->name);
                      //if s1 which is args is null, print (null)
                      if(p->s1 == NULL){
                        PT(level+1);
                        printf("(NULL)\n");
                      }//end if
                      //else call has arguments
                      else{
                        PT(level+1);
                        printf("(\n");
                        ASTprint(level+2, p->s1); //args
                        PT(level+1);
                        printf(")\n");
                      }//end else 
                      break;
        
        //comes from call
        case A_ARGS : PT(level);
                      printf("CALL ARGUMENT\n");
                      ASTprint(level+1, p->s1); //expression
                      ASTprint(level, p->s2); //arglist
                      break;

        //comes from statement aka selection statement
        case A_IFSTMT : PT(level);
                        printf("IF Statement\n");
                        PT(level+1);
                        printf("CONDITION\n");
                        ASTprint(level+2,p->s1); //expression
                        ASTprint(level,p->s2); //ifbody
                        break;

        //comes from ifstmt
        case A_IFBODY : PT(level+1);
                      printf("IF BODY\n");
                      ASTprint(level+2,p->s1); //then statement
                      //if there is an else statement, print else statement 
                      if(p->s2 != NULL){
                        PT(level+1);
                        printf("ELSE\n");
                        ASTprint(level+2,p->s2); //else statement 
                      }//end if
                      break;

        //comes for iteration statement         
        case A_WHILE : PT(level);
                       printf("WHILE\n");
                       PT(level+1);
                       printf("CONDITION\n");
                       ASTprint(level+2, p->s1); //expression
                       PT(level+1);
                       printf("WHILE BODY\n");
                       ASTprint(level+2, p->s2); //statement
                       break;
                       
        //comes from statement
        case A_WRITE:   PT(level);
                        printf("WRITE\n");
                        //if write doesn't have a name, it is just printing a string
                        if(p-> name != NULL){
                            PT(level+1);
                            printf("STRING: %s \n", p->name);
                        }//end if
                        //else go to num
                        else{
                            ASTprint(level+1, p->s1); //NUM
                        }//end else 
                        break;
        
        //comes from statement
        case A_READ:    PT(level);
                        printf("READ \n");
                        ASTprint(level+1, p->s1); //VAR
                        break;
        
        //comes from statement    
        case A_EXPR_STMT: PT(level);
                          printf("Expression Statement \n");
                          ASTprint(level+1,p->s1); //expression
                          break;

        //comes from statement
        case A_ASSIGN_STMT : PT(level);
                        printf("ASSIGNMENT \n");
                        PT(level+1);
                        printf("LEFT HAND SIDE\n"); 
                        ASTprint(level+2,p->s1); //var
                        PT(level+1);
                        printf("RIGHT HAND SIDE\n");
                        ASTprint(level+2,p->s2); //simple expression
                        break;

        //expressions
        case A_EXPR :   PT(level);
                        printf("EXPR ");
                        switch(p -> operator){
                            case A_MINUS: printf("-\n");
                                break;
                            case A_PLUS: printf("+\n");
                                break;
                            case A_MULTIPLY: printf("*\n");
                                break;
                            case A_DIVIDE: printf("/\n");
                                break;
                            case A_LE: printf("<=\n");
                                break;
                            case A_LESS: printf("<\n");
                                break;
                            case A_GREAT: printf(">\n");
                                break;
                            case A_GE: printf(">=\n");
                                break;
                            case A_EQ: printf("==\n");
                                break;
                            case A_NE: printf("!=\n");
                                break;
                            case A_NOT: printf("NOT\n");
                                break;
                            case A_OR : printf("OR\n");
                                break;
                            case A_AND : printf("AND\n");
                                break;
                                         
                            default: printf("Unknown operator in A_EXPR ASTPRINT\n");
                                     printf("EXIT\n ");
                                     exit(1);
                        }//switch
                        ASTprint(level+1, p->s1); //????
                        ASTprint(level+1, p->s2); //????
                        break;
                                       
        default: printf("unknown type in ASTprint %d\n", p->nodetype);
                 printf("Exiting ASTprint immediately\n");
                 exit(1);


       } // of switch

} // of ASTprint




