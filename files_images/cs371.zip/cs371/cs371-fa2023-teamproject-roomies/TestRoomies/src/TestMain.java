import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import sample.EmailSender;

import java.util.Random;

public class TestMain {

    /**
     * This static method saves the users from an ArrayList and stores it into the specified file name, in this instance
     * the filename
     * @param usersList
     * @param filename
     */
    public static void saveUsersToFile(List<Users> usersList, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            for (Users user : usersList) {
                writer.write(user.toCSV());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

     public static void saveUserToFile(Users user, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
                writer.write(user.toCSV());
                writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }   

    /**
     * Method that loads Users from a file, in this instance it will be test.csv and returns an ArrayList containing Users.
     * @param filename
     * @return
     */
    public static List<Users> loadUsersFromFile(String filename) {
        List<Users> usersList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Users user = Users.fromCSV(line);
                usersList.add(user);
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + filename);
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("An I/O error occurred while reading the file: " + filename);
            e.printStackTrace();
        }
        return usersList;
    }

    /**
     * Method that confirms the login of a user by checking the test.csv file and if a match the return will be true if
     * the login information is correct and false if the user failed the login.
     * @return
     */
    public static boolean loggingIn(){
        List<Users> userList = new ArrayList<>(); // ArrayList that will contain the list of users when loaded from csv file.
        Users newUser = new Users(); // New users object that will be used for login comparison.
        Scanner scnr = new Scanner(System.in); //Scanner object to read in user inputted data.
        String username; //String variable to store the inputted username from user.
        String password; //String variable to store the inputted password from user.
        boolean result = false; //Boolean variable to be used to return true or false if login was successful or not.
        int attempts = 0; //Int variable to keep count of the amount of attempts the user has committed.

        System.out.print("\033[H\033[2J"); //Clears the terminal with Linus and macOS.
        System.out.println("-------------Please enter your login information.-------------\n"); //Print statement to direct user.

        while(!result){ //While loop that will ask the user to input their information.
            System.out.print("\tUsername: "); //Print statement to tell the user to enter their username.

            username = scnr.nextLine(); //Scan in the inputted line.
            newUser.setUserName(username); //Set the username that was inputted into new Users object.

            System.out.println();  //Print new line.
            System.out.print("\tPassword: "); //Print statement to tell the user to enter their password.

            password = scnr.nextLine(); //Scan in the inputted line.
            newUser.setPassWord(password); //Set the inputted password into the new User object
            System.out.println(); //Print new line

            userList = TestMain.loadUsersFromFile("test.csv"); //Call loadUsersFromFile method and store the returned array into userList.

            for(Users user : userList){ //For loop that iterates from the array list of userList for each user object.
                if(user.getPassWord().equals(newUser.getPassWord()) && user.getUserName().equals(newUser.getUserName())){ //If password and username are equal, return true.
                    System.out.println("\tWelcome back " + newUser.getUserName() +"!"); //Print statement to welcome back the returning user.
                    return true;
                }
            }

            if(!result && attempts < 4){ //If the username or password was incorrect, direct the user to try again and increase increment attempts.
                System.out.println("\tUsername or password was incorrect. Please try again.\n"); 
                attempts++;
            }

            if(attempts == 4) { //If attempts have exceeded 4, then return false.
                System.out.println("Exceeded amount of attemps allowed. Now exiting.");
                return result;
            }
        }
        return result;
    }

    public static void createOrJoinGroup(Users user){
        Scanner scnr = new Scanner(System.in);
        boolean userAns = true;
        System.out.print("Enter 1 to join a group OR 2 to create a group: ");
        String userInput = scnr.nextLine();
        while(userAns){
            if(userInput.equals("1")){//Go to join a group
                GroupMenu.joinGroup(user);
                break;
            }
            else if(userInput.equals("2")){//Go to create a group

            }
            else if(userInput.equals("q")){
                return;
            }
            else{

            }
        }

        
    }

    public static Users createAccount(){
        Users newUser = new Users(); // New users object that will be used for login comparison.
        Scanner scnr = new Scanner(System.in); // Scanner object to read in user inputted data.
        String username; // String variable to store the inputted username from user.
        String password; // String variable to store the inputted password from user.
        String userEmail;

        System.out.print("\033[H\033[2J"); // Clears the terminal with Linus and macOS.
        System.out.println("-------------Please enter your information to create an account.-------------\n");
        System.out.println("The username must be at least 5 characters long and cannot be any special characters such as \"!@#$%^&*\"\n");

        while(true){
            System.out.print("Username: ");
            username = scnr.nextLine();
            if(Validations.isValidUserName(username)){
                System.out.println("Please enter a valid username.");
            }
            else if(Validations.usedUserName(username)){
                System.out.println("Sorry, that username is already taken. Enter a new username.");
            }
            else{
                newUser.setUserName(username);
                System.out.println();
                break;
            }
        }

        System.out.println("Your password must be at least 8 characters long and contain one captial letter and special character.\n");
        while(true){
            while(true){
            System.out.print("Password: ");
            password = scnr.nextLine();

            if(Validations.isValidPassword(password)){
                System.out.println("Please enter a valid password.");
            }
            else
                break;
            }

            System.out.println("Please confirm password: ");
            while(true){
                System.out.print("Confirm Password: ");
                String testPassword = scnr.nextLine();

                if(!testPassword.equals(password)){
                    System.out.println("Something was misspelt, please retype to confirm password.");
                }
                else{
                    newUser.setPassWord(password);
                    break;
                }
            }
            
            System.out.println("Please enter a valid email address: ");
            while(true){
                System.out.print("Email: ");
                userEmail = scnr.nextLine();

                if(!Validations.isValidEmail(userEmail))
                    System.out.println("Please enter a valid email address");

                else{
                    break;
                }
            }

            System.out.println("Please confirm email: ");
            while(true){
                System.out.print("Confirm email: ");
                String testEmail = scnr.nextLine();

                if(!testEmail.equals(userEmail)){
                    System.out.println("Something was misspelt, please retype to confirm email.");
                }
                else{
                    newUser.setEmailAddress(userEmail);
                    break;
                }
            }
            break;
        }

        EmailSender sender = new EmailSender(); 
        Random rand = new Random();
        int confirmationCode = rand.nextInt(100000,999999);

        sender.sendEmail(newUser.getEmailAddress(), Integer.toString(confirmationCode));

        System.out.println("Please verify your email by entering the confirmation code.");
        int validConfirmation = scnr.nextInt();
        while(true){
            if(validConfirmation != confirmationCode)
                System.out.println("Confirmation codes don't match. Please try again");
            else
                break;
        }

        int newUserIDNumber = rand.nextInt(1000,9999);
        newUser.setIdNumber(newUserIDNumber);

        saveUserToFile(newUser, "test.csv");
        return newUser;
    }
    
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        int loginOrSignup;

        System.out.println("\n-------------Welcome to RoomiesBudget!-------------\n");

        while(true){
            System.out.println("\tPress 1 to login OR 2 to sign up!");

            if(scnr.hasNextInt()){
                loginOrSignup = scnr.nextInt();

                if(loginOrSignup == 1 || loginOrSignup == 2)
                    break;
                else
                    System.out.println("\t++Invalid option. Please enter 1 or 2++\n");
            }

            else{
                System.out.println("\t++Invalid option. Please enter 1 or 2++\n");
                scnr.next();
            }
        }

        if(loginOrSignup == 1){
            loggingIn();
        }
        else{
            Users newUser = createAccount();
            createOrJoinGroup(newUser);
            
        }



        

    }
}
