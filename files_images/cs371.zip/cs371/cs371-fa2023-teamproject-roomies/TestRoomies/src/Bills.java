import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Bills {

    public static void main(String[] args) {
        try {
            // Create a FileWriter to write to the CSV file
            FileWriter csvWriter = new FileWriter("bills.csv");
            BufferedWriter csvBufferedWriter = new BufferedWriter(csvWriter);
            

            Scanner scanner = new Scanner(System.in);

            // Prompt the user to enter bill information
            System.out.println("Enter bill information:");

            System.out.print("Tuition: $");
            double tuition = scanner.nextDouble();

            System.out.print("Car Payments: $");
            double carPayments = scanner.nextDouble();

            System.out.print("Rent: $");
            double rent = scanner.nextDouble();

            System.out.print("Utilities: $");
            double utilities = scanner.nextDouble();

            System.out.print("Credit Card: $");
            double creditCard = scanner.nextDouble();

            System.out.print("WIFI: $");
            double wifi = scanner.nextDouble();

            // Write the bill information to the CSV file
            csvBufferedWriter.write("Tuition" + tuition + "\n");
            csvBufferedWriter.write("Car Payments" + carPayments+"\n");
            csvBufferedWriter.write("Rent" + rent + "\n");
            csvBufferedWriter.write("Utilities" + utilities + "\n");
            csvBufferedWriter.write("Credit Card" + creditCard + "\n");
            csvBufferedWriter.write("WIFI" + wifi + "\n");

            // Close the CSV file
            csvBufferedWriter.close();
            System.out.println("Survey responses saved to groupSurvey_responses.csv.");
            System.out.println("Bills have been saved to bills.csv");
        } catch (IOException e) {
            System.err.println("Error writing to CSV file: " + e.getMessage());
        }
    }
}
