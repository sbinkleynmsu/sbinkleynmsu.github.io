package FinanceTracking;

import java.util.Arrays;

public class Transaction{
    double amount;
    int date;
    String message;


    //Constructor that takes a date of form YYYYMMDD, a message and a transaction amount
    public Transaction (double amnt, int date, String msge){
        amount = amnt;
        this.date = date;
        message = msge;
    }

    public int[] getDate(){
        int num = date;
        double day = 0;
        double month = 0;
        double year = 0;
        for(int i = 0; i < 2; i++){ 
            day = (day * 0.1) + (num % 10);
            num = num / 10;
        }
        day = day * 10;
        for(int i = 0; i < 2; i++){
            month = (month * 0.1) + (num % 10);
            num = num / 10;
        }
        month = month * 10;
        for(int i = 0; i < 4; i++){
            year = (year * 0.1) + (num % 10);
            num = num / 10; 
        }
        year = year * 1000;
        int[] returnDate = {(int) Math.round(year), (int) Math.round(month), (int) Math.round(day)};
        return returnDate;
    }

    static public boolean equals(Transaction c1, Transaction c2){
        if(c1.getMessage() == null && c2.getMessage() == null){
            return true;
        }else if (c1.getMessage() == null || c2.getMessage() == null){
            return false;
        }
        else{
            if (Arrays.equals(c1.getDate(), c2.getDate()) && c1.getAmount() == c2.getAmount() && c1.getMessage().equals(c2.getMessage())){
                return true;
            }
            return false;
        }
    }

    public double getAmount(){
        return amount;
    }

    public String getMessage(){
        return message;
    }

    public String toString(){
        return "Date: " + date + "Amount: " + amount + ", Message: " + message;
    }

    public static void main(String[] args){
        Transaction T_Test = new Transaction(10, 20231016, "hello");
        Transaction T2 = new Transaction(10, 20231016, "hello");
        Transaction T3 = new Transaction(30, 19990912, null);

        System.out.println("~~~~~~~~~~~~~~~~~~~~Get Methods & print~~~~~~~~~~~~~~~~~~~");
        System.out.println(T_Test);
        System.out.println(T_Test.getMessage());
        System.out.println(T_Test.getAmount());
        System.out.println(T_Test.getDate()[0] + ", " + T_Test.getDate()[1] + ", " + T_Test.getDate()[2]);

        System.out.println("~~~~~~~~~~~~~~~~~~~~Comparison~~~~~~~~~~~~~~~~~~~");
        System.out.println(Transaction.equals(T2, T_Test));
        System.out.println(Transaction.equals(T2, T3));
    }
}
