package FinanceTracking;

import java.util.ArrayList;
import java.util.LinkedList;

public class TransactionTracker {
    private ArrayList<ArrayList<ArrayList<LinkedList<Transaction>>>> T_Matrix; //size is 1 year older than recorded oldest person ever :)
    private double total = 0;
    private int startYear;

    public TransactionTracker(double startingFunds, int startingYear) {
        total = startingFunds;
        startYear = startingYear;
        T_Matrix = new ArrayList<ArrayList<ArrayList<LinkedList<Transaction>>>>(117);
        for (int i = 0; i < 117; i++) {
            T_Matrix.add(new ArrayList<ArrayList<LinkedList<Transaction>>>());
            for (int j = 0; j < 12; j++) {
                T_Matrix.get(i).add(new ArrayList<LinkedList<Transaction>>());
                for(int k = 0; k < 31; k++){
                    T_Matrix.get(i).get(j).add(new LinkedList<Transaction>());
                }
            }
        }
    }

    public void add(Transaction toAdd){
        System.out.println(toAdd.getDate()[0] + ", " + toAdd.getDate()[1] + ", " + toAdd.getDate()[2]);
        T_Matrix.get((toAdd.getDate()[0] - startYear))
                    .get(toAdd.getDate()[1] - 1)
                    .get(toAdd.getDate()[2] - 1)
                    .add(toAdd);
        total += toAdd.getAmount();
    }

    public boolean contains(Transaction toSearch){
        LinkedList<Transaction> LL_Comp = getList(toSearch.getDate());
        if(LL_Comp.size() <= 0){
            return false;
        }

        Transaction T_Cursor = LL_Comp.get(0);
        int index = 0;

        while(T_Cursor != null){
            if(Transaction.equals(T_Cursor, toSearch)){
                return true;
            }
            index++;
            T_Cursor = LL_Comp.get(index);
        }
        return false;
    }

    public double getTotal(){
        return total;
    }

    public void print(){
        for(int i = 0; i < 117; i++){
            for(int j = 0; j < 12; j++){
                for(int k = 0; k < 31; k++){
                    if(T_Matrix.get(i).get(j).get(k).size() != 0){
                        System.out.print("Index: " + i + ", " + j + ", " + k + ": ");
                        System.out.println(T_Matrix.get(i).get(j).get(k).toString());
                    }
                }
            }
        }
    }

    public Transaction getTransaction(double amount, int date, String message){
        Transaction toComp = new Transaction(amount, date, message);

        if(!contains(toComp)){
            return null;
        }
        LinkedList<Transaction> tempList =  getList(toComp.getDate());
        int index = 0;
        Transaction cursor = tempList.get(index);

        while(cursor != null){
            if(Transaction.equals(cursor, toComp)){
                return cursor;
            }
            index++;
            cursor = tempList.get(index);
        }
        return null;
    }

    public boolean remove(Transaction toRem){
        if(contains(toRem)){
            int index = getListIndex(toRem);
            LinkedList<Transaction> remList = getList(toRem.getDate());
            remList.remove(index);
            total -= toRem.getAmount();
            return true;
        }
        return false;
    }

    private int getListIndex(Transaction toComp){
        LinkedList<Transaction> tempList =  getList(toComp.getDate());
        int index = 0;
        Transaction cursor = tempList.get(index);

        while(cursor != null){
            if(Transaction.equals(cursor, toComp)){
                return index;
            }
            index++;
            cursor = tempList.get(index);
        }
        return -1;
    }

    private LinkedList<Transaction> getList(int[] date){
        return  T_Matrix.get(date[0] - startYear).get(date[1] - 1).get(date[2] - 1);
    }

    public static void main(String[] args){
        TransactionTracker tracker = new TransactionTracker(0, 2020);

        Transaction T1 = new Transaction(10, 20231016, "hello");
        Transaction T2 = new Transaction(20, 20231016, "help");
        Transaction T3 = new Transaction(30, 20220912, null);
        Transaction T4 = new Transaction(7.00, 20220712, null);

        System.out.println("~~~~~~~~~~~~~~~~~~~~Add Method & print~~~~~~~~~~~~~~~~~~~");
        tracker.add(T1);
        tracker.add(T2);
        tracker.add(T3);
        tracker.print();
        
        System.out.println("~~~~~~~~~~~~~~~~~~~~Get Methods~~~~~~~~~~~~~~~~~~~");
        System.out.println(tracker.getTotal());
        System.out.println(tracker.getTransaction(7.00, 20220712, null));
        System.out.println(tracker.getTransaction(10, 20231016, "hello"));

        System.out.println("~~~~~~~~~~~~~~~~~~~~Contains~~~~~~~~~~~~~~~~~~~");
        System.out.println(tracker.contains(T3));
        System.out.println(tracker.contains(T4));

        System.out.println("~~~~~~~~~~~~~~~~~~~~Private methods~~~~~~~~~~~~~~~~~~~");
        System.out.println(tracker.getListIndex(T2));
        System.out.println(tracker.getList(T3.getDate()));

        System.out.println("~~~~~~~~~~~~~~~~~~~~Remove method~~~~~~~~~~~~~~~~~~~");
        System.out.println(tracker.getTotal());
        tracker.remove(T3);
        tracker.print();
        System.out.println(tracker.getTotal());

    }
}
