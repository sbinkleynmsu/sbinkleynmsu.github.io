package dashboard;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class DashboardController {

    @FXML
    private void handleBillsButtonClick(ActionEvent event) {
        loadNewScene("Bills.fxml", event, "Bills");
    }

    @FXML
    private void handleSettingsButtonClick(ActionEvent event) {
        loadNewScene("Settings.fxml", event, "Settings");
    }

    @FXML
    private void handleNotificationsButtonClick(ActionEvent event) {
        loadNewScene("Notifications.fxml", event, "Notifications");
    }

    @FXML
    private void handleMembersButtonClick(ActionEvent event) {
        loadNewScene("Members.fxml", event, "Members");
    }

    @FXML
    private void handleAddTransactionButtonClick(ActionEvent event) {
        loadNewScene("AddTransaction.fxml", event, "Add Transaction");
    }

    @FXML
    private void handleTransactionHistoryButtonClick(ActionEvent event) {
        loadNewScene("TransactionHistory.fxml", event, "Transactions History");
    }

    @FXML
    private void handleLogOutButtonClick(ActionEvent event){
        loadNewScene("/sample/fxml/WelcomeWindow.fxml", event, "Welcome!");
    }

    private void loadNewScene(String fxmlFileName, ActionEvent event, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlFileName));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();

            // Set the window title dynamically
            stage.setScene(scene);
            stage.setTitle(title);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
