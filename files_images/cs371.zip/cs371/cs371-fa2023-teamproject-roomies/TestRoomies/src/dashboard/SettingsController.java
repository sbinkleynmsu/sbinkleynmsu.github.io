package dashboard;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class SettingsController {

    @FXML
    private Label emailNotificationsLabel;

    @FXML
    private Label rentLabel;

    @FXML
    private Label utilitiesLabel;

    @FXML
    private Label carPaymentsLabel;

    @FXML
    private Label loansLabel;

    @FXML
    private Label debtLabel;

    public void initialize() {
        // Load data from the CSV file and update the labels
        loadDataFromCSV();
    }
    
    private void loadDataFromCSV() {
        String filePath = "TestRoomies/src/surveys/individual_survey_data.csv";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            if ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 6) {
                    emailNotificationsLabel.setText(data[0]);
                    rentLabel.setText(data[1]);
                    utilitiesLabel.setText(data[2]);
                    carPaymentsLabel.setText(data[3]);
                    loansLabel.setText(data[4]);
                    debtLabel.setText(data[5]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void handleBackButtonClick(ActionEvent event) {
        loadDashboardScene(event);
    }

    private void loadDashboardScene(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Dashboard");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleGroupInformationButtonClick(ActionEvent event) {
        loadGroupInformationScene(event);
    }

    private void loadGroupInformationScene(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/surveys/GroupInformation.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Group Information");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
