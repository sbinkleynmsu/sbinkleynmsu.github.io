package dashboard;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import java.io.IOException;

public class AddTransactionController {

    @FXML
    private ComboBox<String> categoryOptions;

    public void initialize() {

        ObservableList<String> categories = FXCollections.observableArrayList(
            "Groceries",
            "Cleaning Supplies",
            "Rent",
            "Internet",
            "Electricity",
            "Water"
        );
        categoryOptions.setItems(categories);
    }

    @FXML
    private TextField customCategory;

    @FXML
    private void handleAddButtonClick(ActionEvent event) {
        String newCategory = customCategory.getText().trim();

        if (newCategory.isEmpty()) {
            return; 
        }

        if (categoryOptions.getItems().contains(newCategory)) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Category Already Exists");
            alert.setHeaderText(null);
            alert.setContentText("The category '" + newCategory + "' already exists.");
            alert.showAndWait();
        }
        
        else {
            categoryOptions.getItems().add(newCategory);
            customCategory.clear();
        }

        if (!newCategory.isEmpty() && !categoryOptions.getItems().contains(newCategory)) {
            categoryOptions.getItems().add(newCategory);
            customCategory.clear();
        }
    }

    @FXML
    private TextField amountTextField;


    @FXML
    private void handleBackButtonClick(ActionEvent event) {
        loadDashboardScene(event);
    }

    private void loadDashboardScene(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Dashboard");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
