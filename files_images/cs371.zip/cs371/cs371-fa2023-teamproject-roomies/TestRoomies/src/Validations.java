import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

/**
 * This class is to be used to clean up some of the code in TestMain. Most of this class 
 * will contain methods that are used for user info validations when logging in or creating a new account.
 */
public class Validations {
    //Final variables that are regular expressions that are to be used for Pattern and Matcher classes to test if a string has those values.

    //EMAIL_PATTERN is a regular expression for having valid email addresses format.
    private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    //USERNAME_PATTERN is a regular expression for anything that is not the characters lowercase, capital alphabet or numbers from 0 to 9.
    private static final String USERNAME_PATTERN = "[^a-zA-Z0-9]";
    //CAPLETTERS is a regular expression for anything that is capital letters.
    private static final String CAPLETTERS = "[A-Z]";

    /**
     * This method tests in the inputted email matches the pattern of a valid email address.
     * @param email
     * @return
     */
    public static boolean isValidEmail(String email) {
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    /**
     * isValidUserName checks to see if the username matches the pattern of the USERNAME_PATTERN and that the length of the string is greater
     * than or equal to 5.
     * @param username
     * @return
     */
    public static boolean isValidUserName(String username){
        Pattern pattern = Pattern.compile(USERNAME_PATTERN);
        Matcher matcher = pattern.matcher(username);

        return matcher.find() || username.length() < 5;
    }

    /**
     * isValidPassword checks to see if the password matches the pattern of USERNAME_PATTERN and CAPLETTERS and that the length of 'password' is greater
     * than or equal to 8.
     * @param password
     * @return
     */
    public static boolean isValidPassword(String password){
        Pattern pattern = Pattern.compile(USERNAME_PATTERN);
        Pattern patternCaps = Pattern.compile(CAPLETTERS);
        Matcher matcher = pattern.matcher(password);
        Matcher matcherCaps = patternCaps.matcher(password);

        return !matcher.find() || password.length() < 8 || !matcherCaps.find();
    }

    /**
     * usedUserName is a method that checks if the inputted username matches any of the usernames that are currently in the csv file that contains the list of Users.
     * In this instance, that file will be test.csv
     * @param username
     * @return
     */
    public static boolean usedUserName(String username){
        List<Users> userList = new ArrayList<>(); // ArrayList that will contain the list of users when loaded from csv file.

        userList = TestMain.loadUsersFromFile("test.csv"); //Call loadUsersFromFile method and store the returned array into userList.

        for(Users user : userList){ //For loop that iterates from the array list of userList for each user object.
            if(username.equals(user.getUserName())){ //If password and username are equal, return true.
                return true;
            }
        }
        return false;
    }
}