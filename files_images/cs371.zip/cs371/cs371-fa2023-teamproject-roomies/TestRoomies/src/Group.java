import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class Group {
    private Users[] members;
    private int numMembers;
    private int groupIDNumber;

    public Users[] getMembers() {
        return members;
    }

    public void setMembers(Users[] members) {
        this.members = members;
    }

    public void addMember(Users user, String filename){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
                writer.write(","+user.getIdNumber());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getNumMembers() {
        return numMembers;
    }

    public void setNumMembers(int numMembers) {
        this.numMembers = numMembers;
    }

    public int getGroupIDNumber() {
        return groupIDNumber;
    }

    public void setGroupIDNumber(int groupIDNumber) {
        this.groupIDNumber = groupIDNumber;
    }

    public Group(){
        members = new Users[10];
        numMembers = 0;
        groupIDNumber = 0;
    }

    public String toString(){
        System.out.println("Group ID: " + groupIDNumber);
        System.out.println();
        for(int i = 0; i < numMembers; i++){
            System.out.println(members[i]);
        }
        return "";
    }

    public static Group fromCSV(String csvLine){
        String[] part = csvLine.split(",");
        List<Users> listUsers = new ArrayList<>();
        Group newGroup = new Group();
        Users newUser = new Users();
        newGroup.groupIDNumber = Integer.parseInt(part[0]);
        listUsers = TestMain.loadUsersFromFile("test.csv");

        for(int i = 1; i < part.length; i++){
            for(Users user : listUsers){
                if(user.getIdNumber() == Integer.parseInt(part[i])){
                    newUser = user;
                    newGroup.members[newGroup.numMembers] = newUser;
                    newGroup.numMembers++;
                }
            }
        }
        return newGroup;
    }

    public String toCSV(){
        StringJoiner joiner = new StringJoiner(",");
        joiner.add(Integer.toString(groupIDNumber));
        for(int i = 0; i < numMembers; i++){
            joiner.add(Integer.toString(members[i].getIdNumber()));
        }
        return joiner.toString();
    }


    public static List<Group> loadGroupsFromFile(String filename) {
        List<Group> groupList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Group groups = Group.fromCSV(line);
                groupList.add(groups);
            }
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + filename);
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("An I/O error occurred while reading the file: " + filename);
            e.printStackTrace();
        }
        return groupList;
    }

    public static void saveGroupToFile(Group group, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
                writer.write(group.toCSV());
                writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }   
}
