package sample;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class Main extends Application { 

    @Override
    public void start(Stage primaryStage) {
        try {
            // Load the FXML file
            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/WelcomeWindow.fxml"));

            // Set the window title
            primaryStage.setTitle("Welcome!");

            // Create a scene and set it as the primary stage's scene
            Scene scene = new Scene(root, 600, 400); // Adjust the size as needed

            //Create new image object and set that image as the icon of the stage
            Image image = new Image("/sample/images/FlowerIcon.png");
            primaryStage.getIcons().add(image);

            primaryStage.setScene(scene);

            // Show the primary stage
            primaryStage.show();
        } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
