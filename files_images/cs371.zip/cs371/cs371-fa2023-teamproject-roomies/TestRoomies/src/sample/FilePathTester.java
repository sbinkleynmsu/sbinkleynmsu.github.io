package sample;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FilePathTester {

    public static void main(String[] args) {
        String filePath = "TestRoomies/src/surveys/GroupSurvey.fxml";

        if (doesPathExist(filePath)) {
            System.out.println("The file pathway exists.");
        } else {
            System.out.println("The file pathway does not exist.");
        }
    }

    public static boolean doesPathExist(String filePath) {
        Path path = Paths.get(filePath);
        return Files.exists(path);
    }
}
