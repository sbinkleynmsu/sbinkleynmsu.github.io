package sample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class Users{
    //Private instance variables that contain username, email, password, and user ID
    private String userName;
    private String emailAddress;
    private String passWord;
    private int idNumber;
    private String firstName;
    private String lastName;
    private boolean isInGroup;

    public Users(){
        userName = "";
        emailAddress = "";
        passWord = "";
        idNumber = 0;
        firstName = "";
        lastName = "";
        isInGroup = false;
    }

    //Get and Set methods
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public int getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    public boolean getIsInGroup() {
        return isInGroup;
    }

    public void setInGroup(boolean isInGroup) {
        this.isInGroup = isInGroup;
    }

    /**
     * Method that takes a Users object and puts it into CSV format
     * @return
     */
    public String toCSV(){
        StringJoiner joiner = new StringJoiner(",");
        joiner.add(userName);
        joiner.add(emailAddress);
        joiner.add(passWord);
        joiner.add(Integer.toString(idNumber));
        joiner.add(firstName);
        joiner.add(lastName);
        joiner.add(Boolean.toString(isInGroup));
        return joiner.toString();
    }

    /**
     * Method that reads from CSV file and returns a Users object with the given information
     * @param csv
     * @return
     */
    public static Users fromCSV(String csv){
        String[] part = csv.split(",");
        Users user = new Users();
        user.setUserName(part[0]);
        user.setEmailAddress(part[1]);
        user.setPassWord(part[2]);
        user.setIdNumber(Integer.parseInt(part[3]));
        user.setFirstName(part[4]);
        user.setLastName(part[5]);
        user.setInGroup(Boolean.parseBoolean(part[6]));

        return user;
    }

        /**
     * This static method saves the users from an ArrayList and stores it into the specified file name, in this instance
     * the filename
     * @param usersList
     * @param filename
     */
    public static void saveUsersToFile(List<Users> usersList, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            for (Users user : usersList) {
                writer.write(user.toCSV());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method does the same as saveUsersToFile but it focuses on adding a single user.
     * @param user
     * @param filename
     */
    public static void saveUserToFile(Users user, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
                    writer.write(user.toCSV());
                    writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }   

    /**
     * Method that loads Users from a file, in this instance it will be test.csv and returns an ArrayList containing Users.
     * @param filename
     * @return
     */
    public static List<Users> loadUsersFromFile(String filename) {
        List<Users> usersList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Users user = Users.fromCSV(line);
                usersList.add(user);
            }
        } catch (FileNotFoundException e) {
            System.out.println("The current directory path is" + new File(".").getAbsolutePath());
            System.err.println("File not found: " + filename);
            e.printStackTrace();
        } catch (IOException e) {
            System.err.println("An I/O error occurred while reading the file: " + filename);
            e.printStackTrace();
        }
        return usersList;
    }

    
    /**
     * toString method that prints out the user data, just being used for testing at the moment.
     */
    public String toString(){
        System.out.println(userName);
        System.out.println(passWord);
        return "";
    }
}
