package sample.controllers;

import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import sample.ShakeAnimation;
import sample.Users;

public class LoginController {
    @FXML
    private TextField textField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField passwordTextField;

    @FXML
    private CheckBox showPasswordCheckBox;

    @FXML
    private Text incorrectInput;

    //Private instance variable that contains the current users from the test.csv file.
    private List<Users> userList = Users.loadUsersFromFile("TestRoomies\\test.csv");

    @FXML
    public void initialize() {
        passwordTextField.setVisible(false); //Set the textfield to be invisible so to have a censored password field shown first.
        incorrectInput.setVisible(false);
    }

    @FXML
    private void handleEnterPressed(ActionEvent event) {
        int counter = 0;
        String enteredUsername = textField.getText();
        String enteredPassword = null;

        String password = passwordField.getText();
        String textFieldPassword = passwordTextField.getText();

        /*This nested if statement is to ensure that the entered password is 
         * updated with the correct password string since currently the user can enter one field without 
         * updating the other (with its text) if they don't reclick the showPasswordCheckbox*/
        if (!password.equals(textFieldPassword)) {
            int comparisonResult = password.compareTo(textFieldPassword);
            if (comparisonResult > 0) {
                enteredPassword = password;
            } else if (comparisonResult < 0) {
                enteredPassword = textFieldPassword;
            }
        }
        Users loggedInUser = new Users();
        for(Users user : userList){ //For loop that iterates from the array list of userList for each user object.
            if((user.getPassWord().equals(enteredPassword) && user.getUserName().equals(enteredUsername)
            || (user.getPassWord().equals(textFieldPassword)) && user.getUserName().equals(enteredUsername))){ //If password and username are equal, return true.
                incorrectInput.setVisible(false);
                System.out.println("\tWelcome back " + enteredUsername +"!"); //Print statement to welcome back the returning user.
                loggedInUser = user;
                break;
            }
            counter++;
        }

        if(counter != userList.size()){
            if(!loggedInUser.getIsInGroup()){
                try {
                Stage stage = (Stage) textField.getScene().getWindow();
    
                Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/CreateOrJoinGroup.fxml"));
    
                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Dashboard");
            } catch (Exception e) {
                // Handle exceptions here, e.g., log the error and provide a user-friendly message
                e.printStackTrace();
            }
            }
            else{
            try {
                Stage stage = (Stage) textField.getScene().getWindow();
    
                Parent root = FXMLLoader.load(getClass().getResource("/dashboard/Dashboard.fxml"));
    
                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Dashboard");
            } catch (Exception e) {
                // Handle exceptions here, e.g., log the error and provide a user-friendly message
                e.printStackTrace();
            }
            }
        }

        else{
            incorrectInput.setVisible(true);
            ShakeAnimation.shake(incorrectInput);
        }
    }

    @FXML
    private void showPasswordVisibility(){
        if(showPasswordCheckBox.isSelected()){
            passwordTextField.setText(passwordField.getText());
            passwordTextField.setVisible(true);
            passwordField.setVisible(false);
        }
        else{    
            passwordField.setText(passwordTextField.getText());
            passwordTextField.setVisible(false);
            passwordField.setVisible(true);
        }    
    }

    public void backButtonClick(ActionEvent event){
        try {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/WelcomeWindow.fxml"));

            Scene secondaryScene = new Scene(root, 600, 400);
            Image image = new Image("/sample/images/FlowerIcon.png");
            stage.getIcons().add(image);
            stage.setScene(secondaryScene);
        } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }
    
}
