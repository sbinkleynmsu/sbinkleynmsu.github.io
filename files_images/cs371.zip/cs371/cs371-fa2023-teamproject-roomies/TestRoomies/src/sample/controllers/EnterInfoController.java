package sample.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import sample.ShakeAnimation;
import sample.Validations;
import sample.ShakeAnimation;

public class EnterInfoController extends Validations{
    @FXML
    private TextField userNameTextField;

    @FXML
    private TextField passwordTextField;

    @FXML
    private TextField confirmPasswordTF;

    @FXML
    private Button continueButton;

    @FXML
    private Button backButton;

    @FXML
    private Text userNameTaken;

    @FXML
    private Text userNameInvalid;

    @FXML
    private Text passwordInvalid;

    @FXML
    private Text confirmPWInvalid;

    //This data will maintain the data the user has entered to be used across scenes.
    DataUserEntered data = DataUserEntered.getInstance();

    @FXML
    public void initialize() {
        userNameTaken.setVisible(false);
        userNameInvalid.setVisible(false);
        passwordInvalid.setVisible(false);
        confirmPWInvalid.setVisible(false);

        //This is a test to show that the DataUserEntered is working properly and is transfering data between scenes.
        System.out.println("Hello " + data.getFirstname() + " " + data.getLastname());
    }

    public void backButtonClick(ActionEvent event){
        try {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/CreateAccountWindow.fxml"));

            Scene secondaryScene = new Scene(root, 600, 400);
            Image image = new Image("/sample/images/FlowerIcon.png");
            stage.getIcons().add(image);
            stage.setScene(secondaryScene);
            stage.setTitle("Create Account");
        } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }

    public void nextButtonClicked(ActionEvent event){
            String enteredUsername = userNameTextField.getText().trim();
            String enteredPassword = passwordTextField.getText().trim();
            String enteredConfirmedPW = confirmPasswordTF.getText().trim();

            //These nested if statements check that the username is valid, if the user name is taken, or if that it is valid and not taken
            //-------------------------------------------------------------------
            userNameConfirmation(enteredUsername);
            passWordConfirmation(enteredPassword, enteredConfirmedPW);

            if(userNameConfirmation(enteredUsername) && passWordConfirmation(enteredPassword, enteredConfirmedPW)){
                System.out.println("Welcome!!!");
                try {
                    data.setUsername(enteredUsername);
                    data.setPassword(enteredPassword);

                    Stage stage = (Stage) userNameTextField.getScene().getWindow();

                    Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/EnterEmail.fxml"));

                    Scene secondaryScene = new Scene(root, 600, 400);
                    Image image = new Image("/sample/images/FlowerIcon.png");
                    stage.getIcons().add(image);
                    stage.setScene(secondaryScene);
                } catch (Exception e) {
                    // Handle exceptions here, e.g., log the error and provide a user-friendly message
                    e.printStackTrace();
                }
            }
    }

    /**
     * This method checks is the username is valid and not taken, it will also do the animations for the 
     * error messages and responsible for setting the fields to be visible or not depending on the input
     * @param enteredUsername
     * @return true if the username is valid and not taken or false if the username doesn't meet requirements.
     */
    private boolean userNameConfirmation(String enteredUsername){
        if (!userNameValid(enteredUsername)) {
                System.out.println("Username is not valid");
                userNameTaken.setVisible(false);
                userNameInvalid.setVisible(true);
                ShakeAnimation.shake(userNameInvalid);
                return false;
            } 
        else if (usedUserName(enteredUsername)) {
                System.out.println("Username is already taken");
                userNameInvalid.setVisible(false);
                userNameTaken.setVisible(true);
                ShakeAnimation.shake(userNameTaken);
                return false;
            } 
        else {
                System.out.println("Username is valid and not taken");
                userNameInvalid.setVisible(false);
                userNameTaken.setVisible(false);
                return true;
            }
    }

    /**
     * This method checks if the password is valid and that the confirmation password also matches up with
     * the entered password.
     * @param enteredPassword
     * @param enteredConfirmedPW
     * @return
     */
    private boolean passWordConfirmation(String enteredPassword, String enteredConfirmedPW){
        //This if-else statement checks if the valid is a valid password
            if (Validations.isValidPassword(enteredPassword)) {
                System.out.println("Valid password");
                passwordInvalid.setVisible(false);
            }
            else {
                System.out.println("Invalid Password");
                passwordInvalid.setVisible(true);
                ShakeAnimation.shake(passwordInvalid);
                System.out.println(enteredPassword);
                return false;
            }

            //This if-else statement simply checks if the entered password is the same as the entered confirm password
            if(enteredConfirmedPW.isEmpty() || !enteredConfirmedPW.equals(enteredPassword)){
                System.out.println("Your password was typed wrong, try again");
                confirmPWInvalid.setVisible(true);
                ShakeAnimation.shake(confirmPWInvalid);
                return false;
            }
            else{
                confirmPWInvalid.setVisible(false);
                return true;
            }
    }
}
