package sample.controllers;

import java.util.Random;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import sample.EmailSender;
import sample.Users;

public class ConfirmationCodeController {

    @FXML
    private TextField confirmTextField;

    @FXML
    private Button continueButton;

    @FXML
    private Button backButton;

    DataUserEntered data = DataUserEntered.getInstance();

    private int confirmationCode;

    @FXML
    public void initialize() {
        System.out.println("Name: " + data.getFirstname() + " " + data.getLastname());
        System.out.println("Username: " + data.getUsername());
        System.out.println("Password: " + data.getPassword());
        System.out.println("Email Address: " + data.getEmailAddress());

        //Send out the email.
        EmailSender sender = new EmailSender(); 
        Random rand = new Random();
        confirmationCode = rand.nextInt(100000,999999);

        //FIX ME--Need to change newUser email with either sending the data between controllers or creating a new user.
        sender.sendEmail(data.getEmailAddress(), Integer.toString(confirmationCode));
    }

    public void nextButtonClicked(ActionEvent event){
        String enteredConfirmCode = confirmTextField.getText().trim();

        if(confirmationCode == Integer.parseInt(enteredConfirmCode)){
            Random rand = new Random();
            System.out.println("YOU HAVE ENTERED THE RIGHT CONFIRMATION CODE");

            Users newUser = new Users();
            newUser.setFirstName(data.getFirstname());
            newUser.setLastName(data.getLastname());
            newUser.setUserName(data.getUsername());
            newUser.setPassWord(data.getPassword());
            newUser.setEmailAddress(data.getEmailAddress());
            newUser.setIdNumber(confirmationCode);
            int newUserIDNumber = rand.nextInt(1000,9999);
            newUser.setIdNumber(newUserIDNumber);
            Users.saveUserToFile(newUser,"TestRoomies\\test.csv");

            try {
                Stage stage = (Stage) confirmTextField.getScene().getWindow();

                Parent root = FXMLLoader.load(getClass().getResource("/surveys/IndividualSurvey.fxml"));

                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Create Account");
            } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
        }
        else{
            System.out.println("YOU DID NOT ENTER THE RIGHT CODE.");
        }
    }

    public void backButtonClick(ActionEvent event){
        try {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/EnterEmail.fxml"));

            Scene secondaryScene = new Scene(root, 600, 400);
            Image image = new Image("/sample/images/FlowerIcon.png");
            stage.getIcons().add(image);
            stage.setScene(secondaryScene);
        } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }    

}
