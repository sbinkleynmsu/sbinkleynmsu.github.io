package sample.controllers;

public class JoinGroupController {
    
}
