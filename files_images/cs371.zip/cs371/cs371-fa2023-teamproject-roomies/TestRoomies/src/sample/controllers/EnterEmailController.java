package sample.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import sample.Validations;

public class EnterEmailController {
    @FXML
    private TextField emailAddress;

    @FXML
    private TextField confirmEmailAddress;

    @FXML
    private Button continueButton;

    @FXML
    private Button backButton;

    DataUserEntered data = DataUserEntered.getInstance();

    @FXML
    public void initialize() {
        System.out.println("Name: " + data.getFirstname() + " " + data.getLastname());
        System.out.println("Username: " + data.getUsername());
        System.out.println("Password: " + data.getPassword());
    }

    public void nextButtonClicked(ActionEvent event){
        String enteredEmail = emailAddress.getText().trim();
        String enteredConfirmEmail = confirmEmailAddress.getText().trim();

        if(validEmail(enteredEmail) && confirmEmailValid(enteredConfirmEmail, enteredEmail)){
            System.out.println("WELCOME!!!");
            try {
                data.setEmailAddress(enteredConfirmEmail);
                Stage stage = (Stage) emailAddress.getScene().getWindow();

                Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/ConfirmationCode.fxml"));

                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Create Account");
            } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
        }
    }

    public void backButtonClick(ActionEvent event){
        try {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/EnterUsernamePW.fxml"));

            Scene secondaryScene = new Scene(root, 600, 400);
            Image image = new Image("/sample/images/FlowerIcon.png");
            stage.getIcons().add(image);
            stage.setScene(secondaryScene);
            stage.setTitle("Create Account");
        } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }

    /**
     * Method that checks the given email is valid format and is not taken.
     * @param enteredEmail
     * @return true that the email is valid and not taken, and false for anything else.
     */
    private boolean validEmail(String enteredEmail){
        if(!Validations.isValidEmail(enteredEmail)){
            System.out.println("NOT valid Email.");
        }
        else if (Validations.usedEmail(enteredEmail)){
            System.out.println("Valid email but it is being used already.");
        }
        else{
            System.out.println("Valid email and not taken!");
            return true;
        }
        return false;
    }

    /**
     * This method checks to see that the entered confirm email text field matches the entered email text field.
     * @param enteredConfirmEmail
     * @param enteredEmail
     * @return true if both text fields are equal and false for else.
     */
    private boolean confirmEmailValid(String enteredConfirmEmail, String enteredEmail){
        if(!enteredConfirmEmail.isEmpty() && enteredConfirmEmail.equals(enteredEmail)){
            System.out.println("Welcome!");
            return true;
        }

        System.out.println("Please confirm email");
        return false;
    }
    
}
