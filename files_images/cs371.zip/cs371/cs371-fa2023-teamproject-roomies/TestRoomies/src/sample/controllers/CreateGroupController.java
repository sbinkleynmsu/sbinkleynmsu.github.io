package sample.controllers;

import java.util.Random;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import sample.Users;

public class CreateGroupController {
    @FXML
    private Button logoutButton;

    @FXML
    private Button continueButton;

    @FXML
    private TextField groupNameTextField;

    public void nextButtonClicked(ActionEvent event){

        if(groupNameTextField.getText() == ""){
            System.out.println("Please enter a group name.");
        }

        else{
        try {
                Stage stage = (Stage) groupNameTextField.getScene().getWindow();

                Parent root = FXMLLoader.load(getClass().getResource("/surveys/GroupSurvey.fxml"));

                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Create Account");
            } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }
    }
}
