package sample.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class CreateOrJoinGroupController {
    @FXML
    private Button createGroupButton;

    @FXML
    private Button joinGroupButton;

    @FXML
    private Button logoutButton;

    public void createGroupButtonClicked(ActionEvent event){
        try {

                Stage stage = (Stage) createGroupButton.getScene().getWindow();
    
                Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/CreateGroup.fxml"));

                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Create Group");
            } catch (Exception e) {
                // Handle exceptions here, e.g., log the error and provide a user-friendly message
                e.printStackTrace();
            }
    }

    public void joinGroupButtonClicked(ActionEvent event){
        try {

                Stage stage = (Stage) createGroupButton.getScene().getWindow();
    
                Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/JoinGroup.fxml"));

                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Join Group");
            } catch (Exception e) {
                // Handle exceptions here, e.g., log the error and provide a user-friendly message
                e.printStackTrace();
            }
    }

    public void logoutButtonClicked(ActionEvent event){
        try {

                Stage stage = (Stage) createGroupButton.getScene().getWindow();
    
                Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/WelcomeWindow.fxml"));

                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Welcome!");
            } catch (Exception e) {
                // Handle exceptions here, e.g., log the error and provide a user-friendly message
                e.printStackTrace();
            }
    }
}
