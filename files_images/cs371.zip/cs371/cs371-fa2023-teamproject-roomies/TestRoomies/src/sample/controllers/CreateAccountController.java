package sample.controllers;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import sample.Validations;

public class CreateAccountController{
    @FXML
    private TextField firstname;

    @FXML
    private TextField lastname;

    @FXML
    private Button nextButton;

    @FXML
    private Button backButton;

    //This data will maintain the data the user has entered to be used across scenes.
    DataUserEntered data = DataUserEntered.getInstance();

    public void backButtonClick(ActionEvent event){
        try {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/WelcomeWindow.fxml"));

            Scene secondaryScene = new Scene(root, 600, 400);
            Image image = new Image("/sample/images/FlowerIcon.png");
            stage.getIcons().add(image);
            stage.setScene(secondaryScene);
            stage.setTitle("Welcome");
        } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }

    public void nextButtonClicked(ActionEvent event){
        String[] firstnameSplit = firstname.getText().split(" ");
        String firstnameString = "";
        for(String firstnameElements : firstnameSplit){
            firstnameString += firstnameElements;
        }

        String[] lastnameSplit = lastname.getText().split(" ");
        String lastnameString = "";
        for(String lastnameElements : lastnameSplit){
            lastnameString += lastnameElements;
        }

        boolean firstnameValid = Validations.createAccountNamesValid(firstnameString);
        boolean lastnameValid = Validations.createAccountNamesValid(lastnameString);

        if(!firstnameString.isEmpty() && !lastnameString.isEmpty() && firstnameValid && lastnameValid){
            System.out.println(firstnameString + " " + lastnameString + " was entered.");
            try {
                
                data.setFirstname(firstnameString);
                data.setLastname(lastnameString);

                Stage stage = (Stage) firstname.getScene().getWindow();
    
                Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/EnterUsernamePw.fxml"));

                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Create Account");
            } catch (Exception e) {
                // Handle exceptions here, e.g., log the error and provide a user-friendly message
                e.printStackTrace();
            }
        }

        else
            System.out.println("Please enter a valid first and last name for your account.");
    }


}
