package sample.controllers;

public class DataUserEntered {
    private static final DataUserEntered instance = new DataUserEntered();

    private String firstname;
    private String lastname;
    private String username;
    private String password;
    private String emailAddress;
    private boolean isInGroup;

    private DataUserEntered(){}

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public boolean isInGroup() {
        return isInGroup;
    }

    public void setInGroup(boolean isInGroup) {
        this.isInGroup = isInGroup;
    }

    public static DataUserEntered getInstance(){
        return instance;
    }

    
}
