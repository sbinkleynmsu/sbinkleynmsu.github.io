package sample.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class Controller {

    public void loginButtonClicked(ActionEvent event){
        try {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/LoginWindow.fxml"));

            Scene secondaryScene = new Scene(root, 600, 400);
            Image image = new Image("/sample/images/FlowerIcon.png");
            stage.getIcons().add(image);
            stage.setScene(secondaryScene);
            stage.setTitle("Login");
        } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }

    public void CreateAccountButtonClicked(ActionEvent event){
        try {
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/CreateAccountWindow.fxml"));

            Scene secondaryScene = new Scene(root, 600, 400);
            Image image = new Image("/sample/images/FlowerIcon.png");
            stage.getIcons().add(image);
            stage.setScene(secondaryScene);
            stage.setTitle("Create Account");
        } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }
}
