package sample;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validations {

    //EMAIL_PATTERN is a regular expression for having valid email addresses format.
    private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    //USERNAME_PATTERN is a regular expression for anything that is not the characters lowercase, capital alphabet or numbers from 0 to 9.
    private static final String USERNAME_PATTERN = "[^a-zA-Z0-9]";
    //CAPLETTERS is a regular expression for anything that is capital letters.
    private static final String CAPLETTERS = "[A-Z]";
    
    public static boolean createAccountNamesValid(String name){
        Pattern pattern = Pattern.compile(".*[^a-zA-Z]+.*");
        Matcher matcher = pattern.matcher(name);

        if(matcher.matches()){
            return false;
        }       
        return true;
    } 

    /**
     * This method checks if the username is a valid sequence with no spaces in between the characters.
     * @param userName
     * @return boolean true if the string doesn't match the space between characters or false if it does.
     */
    public static boolean userNameValid(String userName){
        // Define a regular expression to match spaces between characters
        Pattern specialCharPattern = Pattern.compile("[^a-zA-Z0-9]");

        // Create a Matcher object to find matches in the input string
        Matcher specialCharMatcher = specialCharPattern.matcher(userName);

        // Create a trimmed user name string that will get rid of any trailing or leading spaces in the input.
        String trimmedUserName = userName.trim();
        
        //Check if the username has spaces in between, matches any special characters, or the length is less than 5; then return false.
        if(trimmedUserName.contains(" ") || specialCharMatcher.matches() || userName.length() < 5){
            return false;
        }

        return true;
    }

        /**
     * usedUserName is a method that checks if the inputted username matches any of the usernames that are currently in the csv file that contains the list of Users.
     * In this instance, that file will be test.csv
     * @param username
     * @return
     */
    public static boolean usedUserName(String username){
        List<Users> userList = new ArrayList<>(); // ArrayList that will contain the list of users when loaded from csv file.

        userList = Users.loadUsersFromFile("TestRoomies\\test.csv"); //Call loadUsersFromFile method and store the returned array into userList.

        for(Users user : userList){ //For loop that iterates from the array list of userList for each user object.
            if(username.equals(user.getUserName())){ //If entered username and listed username are equal, return true.
                return true;
            }
        }
        return false;
    }

    /**
     * This method checks if the given email address matches any of the already existing users' email
     * @param email
     * @return True if the given email address is used or False if the email address is not being used.
     */
    public static boolean usedEmail(String email){
        List<Users> userList = new ArrayList<>(); // ArrayList that will contain the list of users when loaded from csv file.

        userList = Users.loadUsersFromFile("TestRoomies\\test.csv"); //Call loadUsersFromFile method and store the returned array into userList.

        for(Users user : userList){ //For loop that iterates from the array list of userList for each user object.
            if(email.equals(user.getEmailAddress())){ //If entered username and listed username are equal, return true.
                return true;
            }
        }
        return false;
    }

        /**
     * isValidPassword checks to see if the password matches the pattern of USERNAME_PATTERN and CAPLETTERS and that the length of 'password' is greater
     * than or equal to 8.
     * @param password
     * @return
     */
    public static boolean isValidPassword(String password) {
        // Check if the password is at least 8 characters long
        if (password.length() < 8) {
            return false;
        }
    
        // Check if the password contains at least one capital letter
        Pattern patternCaps = Pattern.compile(CAPLETTERS);
        Matcher matcherCaps = patternCaps.matcher(password);
        if (!matcherCaps.find()) {
            return false;
        }
    
        // Check if the password contains at least one digit (number)
        if (!password.matches(".*\\d.*")) {
            return false;
        }

        if (!password.matches(".*[^a-zA-Z0-9].*")) {
            return false;
        }
    
        return true; // Password meets all criteria
    }

    /**
     * This method tests in the inputted email matches the pattern of a valid email address.
     * @param email
     * @return
    */
    public static boolean isValidEmail(String email) {
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return (!email.contains(" ")) && matcher.matches();
    }
    
}
