package sample;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Group {
    private List<Integer> groupMemberIDnumbers;
    private String name;
    private int groupIDNumber;

    public List<Integer> getGroupMemberIDnumbers() {
        return groupMemberIDnumbers;
    }

    public void setGroupMemberIDnumbers(List<Integer> groupMemberIDnumbers) {
        this.groupMemberIDnumbers = groupMemberIDnumbers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Group(String name, int groupIDNumber, List<Integer> groupMemberIDnumbers) {
        this.name = name;
        this.groupIDNumber = groupIDNumber;
        this.groupMemberIDnumbers = groupMemberIDnumbers;
    }

    public List<Integer> getGroupIDNumberroupMemberIDnumbers() {
        return groupMemberIDnumbers;
    }

    public void addMember(Users user, String filename){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
                writer.write(","+user.getIdNumber());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getGroupIDNumber() {
        return groupIDNumber;
    }

    public void setGroupIDNumber(int groupIDNumber) {
        this.groupIDNumber = groupIDNumber;
    }

    public static List<Group> loadGroupsFromFile(String filePath) throws IOException {
        List<Group> groups = new ArrayList<>();

        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;

        while ((line = reader.readLine()) != null) {
            String[] values = line.split(",");
            String groupName = values[0];
            int groupId = Integer.parseInt(values[1]);
            List<Integer> groupMembers = new ArrayList<>();

            for (int i = 2; i < values.length; i++) {
                groupMembers.add(Integer.parseInt(values[i]));
            }

            Group group = new Group(groupName, groupId, groupMembers);
            groups.add(group);
        }

        reader.close();
        return groups;
    }

    public static void modifyGroupCSVFile(String filePath, String valueToMatch, int valueToAppend) throws IOException {
        // Read the existing content of the CSV file
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        StringBuilder modifiedContent = new StringBuilder();

        while ((line = reader.readLine()) != null) {
            String[] values = line.split(",");

            // Check if the first value matches the specified string
            if (values[0].equals(valueToMatch)) {
                // Append the desired value to the end of the matched line
                line += "," + valueToAppend;
            }

            // Append the modified line to the content
            modifiedContent.append(line);
            modifiedContent.append(System.lineSeparator());
        }

        reader.close();

        // Write the modified content back to the CSV file
        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
        writer.write(modifiedContent.toString());
        writer.close();
    }

    
    @Override
    public String toString() {
        return "Group{" +
                "name='" + name + '\'' +
                ", id=" + groupIDNumber +
                ", members=" + groupMemberIDnumbers +
                '}';
    }

    public static void main(String[] args) {
        // Specify the path to your CSV file
        String csvFilePath = "TestRoomies\\groupTest.csv";

        // The value to match in the first column
        String valueToMatch = "name2";

        // The value to append to the matched line
        int valueToAppend = 9999;

        try {
            modifyGroupCSVFile(csvFilePath, valueToMatch, valueToAppend);
            System.out.println("Value appended successfully to the matching line of the CSV file.");
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }

        try {
            List<Group> groups = loadGroupsFromFile(csvFilePath);
            for (Group group : groups) {
                System.out.println(group);
            }
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

}
