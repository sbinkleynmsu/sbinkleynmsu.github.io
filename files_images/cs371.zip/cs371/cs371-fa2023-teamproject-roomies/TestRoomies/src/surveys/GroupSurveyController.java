package surveys;

import java.io.FileWriter;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class GroupSurveyController {

    @FXML
    private Button backButton;

    @FXML
    private RadioButton roommateRadioButton; 

    @FXML
    private RadioButton familyRadioButton;

    @FXML
    private RadioButton tempLivingSituationRadioButton;

    @FXML
    private TextField rentField;

    @FXML
    private TextField utilitiesField;

    @FXML
    private RadioButton costsYesRadioButton;

    @FXML
    private RadioButton costsNoRadioButton;

    @FXML
    private Button nextButton;

    private String groupPurpose;
    private String rent;
    private String utilities;
    private String splitCosts;

    @FXML
    private void handleBackButtonClick() {
        loadPreviousScene();
    }

    private void loadPreviousScene() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/dashboard/Dashboard.fxml")); 
            Scene scene = new Scene(root, 600, 400);
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Dashboard");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRoommateRadioButtonClick() {
        familyRadioButton.setSelected(false);
        tempLivingSituationRadioButton.setSelected(false);
    }

    @FXML
    private void handleFamilyRadioButtonClick() {
        roommateRadioButton.setSelected(false);
        tempLivingSituationRadioButton.setSelected(false);
    }

    @FXML
    private void handleTempLivingSituationRadioButtonClick() {
        roommateRadioButton.setSelected(false);
        familyRadioButton.setSelected(false);
    }

    private String groupPurposeRadioButtonText() {
        if (roommateRadioButton.isSelected()) {
            handleRoommateRadioButtonClick();
            return roommateRadioButton.getText();
        } else if (familyRadioButton.isSelected()) {
            handleFamilyRadioButtonClick();
            return familyRadioButton.getText();
        } else if (tempLivingSituationRadioButton.isSelected()) {
            handleRoommateRadioButtonClick();
            return tempLivingSituationRadioButton.getText();
        }  else {
            return "No selection"; 
        }
    }

    @FXML
    private void handleYesRadioButtonClick() {
        costsNoRadioButton.setSelected(false);
    }

    @FXML
    private void handleNoRadioButtonClick() {
        costsYesRadioButton.setSelected(false);
    }

    private String costRadioButtonText() {
        if (costsYesRadioButton.isSelected()) {
            handleYesRadioButtonClick();
            return costsYesRadioButton.getText();
        } else if (costsNoRadioButton.isSelected()) {
            handleNoRadioButtonClick();
            return costsNoRadioButton.getText();
        }  else {
            return "No selection"; 
        }
    }

    @FXML
    private void handleNextButtonClick() {
        groupPurpose = groupPurposeRadioButtonText();
        rent = rentField.getText();
        utilities = utilitiesField.getText();
        splitCosts = costRadioButtonText();

        // print user inputs for testing purposes
        System.out.println("1. Group Purpose: " + groupPurpose);
        System.out.println("2. Rent: " + rent);
        System.out.println("3. Utilities: " + utilities);
        System.out.println("4. Split Costs: " + splitCosts);

        saveToCSV(groupPurpose, rent, utilities, splitCosts);

        try {
                Stage stage = (Stage) nextButton.getScene().getWindow();

                Parent root = FXMLLoader.load(getClass().getResource("/dashboard/Dashboard.fxml"));

                Scene secondaryScene = new Scene(root, 600, 400);
                Image image = new Image("/sample/images/FlowerIcon.png");
                stage.getIcons().add(image);
                stage.setScene(secondaryScene);
                stage.setTitle("Create Account");
            } catch (Exception e) {
            // Handle exceptions here, e.g., log the error and provide a user-friendly message
            e.printStackTrace();
        }
    }

    private void saveToCSV(String groupPurpose, String rent, String utilities, String splitCosts) {
        String filePath = "TestRoomies/src/surveys/group_survey_data.csv";
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.append(groupPurpose + ",");
            writer.append(rent + ",");
            writer.append(utilities + ",");
            writer.append(splitCosts + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
