package surveys;

public class IndividualSurveyClass {
    private int userIDNumber;
    private boolean popUpNotifications;
    private int rentAmount;
    private int utilitiesAmount;
    private int carPayments;
    private int loanPayments;
    private int debtPayments;

    public IndividualSurveyClass(){
        userIDNumber = 0;
        popUpNotifications = false;
        rentAmount = 0;
        utilitiesAmount = 0;
        carPayments = 0;
        loanPayments = 0;
        debtPayments = 0;
    }

    public int getUserIDNumber() {
        return userIDNumber;
    }

    public void setUserIDNumber(int userIDNumber) {
        this.userIDNumber = userIDNumber;
    }

    public boolean isPopUpNotifications() {
        return popUpNotifications;
    }

    public void setPopUpNotifications(boolean popUpNotifications) {
        this.popUpNotifications = popUpNotifications;
    }

    public int getRentAmount() {
        return rentAmount;
    }

    public void setRentAmount(int rentAmount) {
        this.rentAmount = rentAmount;
    }

    public int getUtilitiesAmount() {
        return utilitiesAmount;
    }

    public void setUtilitiesAmount(int utilitiesAmount) {
        this.utilitiesAmount = utilitiesAmount;
    }

    public int getCarPayments() {
        return carPayments;
    }

    public void setCarPayments(int carPayments) {
        this.carPayments = carPayments;
    }

    public int getLoanPayments() {
        return loanPayments;
    }

    public void setLoanPayments(int loanPayments) {
        this.loanPayments = loanPayments;
    }

    public int getDebtPayments() {
        return debtPayments;
    }

    public void setDebtPayments(int debtPayments) {
        this.debtPayments = debtPayments;
    }

    
}
