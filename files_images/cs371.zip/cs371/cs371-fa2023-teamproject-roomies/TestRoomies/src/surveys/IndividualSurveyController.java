package surveys;

import java.io.FileWriter;
import java.io.IOException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class IndividualSurveyController extends Application {

    @FXML
    private TextField rentField;
    
    @FXML
    private TextField utilitiesField;
    
    @FXML
    private TextField carPaymentsField;
    
    @FXML
    private TextField loansField;
    
    @FXML
    private TextField debtField;
    
    @FXML
    private RadioButton yesRadioButton;
    
    @FXML
    private RadioButton noRadioButton;

    @FXML
    private void handleYesRadioButtonClick() {
        noRadioButton.setSelected(false);
    }

    @FXML
    private void handleNoRadioButtonClick() {
        yesRadioButton.setSelected(false);
    }

    @FXML
    private void handleBackButtonClick(ActionEvent event) {
        loadConfirmationCodeScene(event);
    }

    private void loadConfirmationCodeScene(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/ConfirmationCode.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Create Account");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleNextButtonClick(ActionEvent event) {
        String rent = rentField.getText();
        String utilities = utilitiesField.getText();
        String carPayments = carPaymentsField.getText();
        String loans = loansField.getText();
        String debt = debtField.getText();
        String emailNotifications = getSelectedRadioButtonText();
        // print to the command line for testing purposes
        System.out.println("1. Email Notifications: " + emailNotifications);
        System.out.println("2. Rent: " + rent);
        System.out.println("3. Utilities: " + utilities);
        System.out.println("4. Car Payments: " + carPayments);
        System.out.println("5. Loans: " + loans);
        System.out.println("6. Debt: " + debt);

        saveToCSV(emailNotifications, rent, utilities, carPayments, loans, debt);
        loadNextScene(event);
    }

    private void saveToCSV(String emailNotifications, String rent, String utilities, String carPayments, String loans, String debt) {
        String filePath = "TestRoomies/src/surveys/individual_survey_data.csv";
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.append(emailNotifications + ",");
            writer.append(rent + ",");
            writer.append(utilities + ",");
            writer.append(carPayments + ",");
            writer.append(loans + ",");
            writer.append(debt + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadNextScene(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/sample/fxml/CreateOrJoinGroup.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Create or Join Group");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // create a ToggleGroup for the radio buttons
    private ToggleGroup radioGroup = new ToggleGroup();

    private String getSelectedRadioButtonText() {
        if (yesRadioButton.isSelected()) {
            handleYesRadioButtonClick();
            return yesRadioButton.getText();
        } else if (noRadioButton.isSelected()) {
            handleNoRadioButtonClick();
            return noRadioButton.getText();
        } else {
            return "No selection"; 
        }
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("IndividualSurvey.fxml"));
        Pane root = loader.load();
        
        loader.setController(this);

        // set the ToggleGroup for the radio buttons
        yesRadioButton.setToggleGroup(radioGroup);
        noRadioButton.setToggleGroup(radioGroup);

        Scene scene = new Scene(root, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Individual Survey");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
        
}




