package surveys;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class GroupInformationController {
    
    @FXML
    private Label groupPurposeLabel;

    @FXML
    private Label rentLabel;

    @FXML
    private Label utilitiesLabel;

    @FXML
    private Label splitCostLabel;

    @FXML
    private void handleBackButtonClick(ActionEvent event) {
        loadPreviousScene(event);
    }

    private void loadPreviousScene(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/dashboard/Settings.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Settings");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void initialize() {
        loadDataFromCSV();
    }
    
    private void loadDataFromCSV() {
        String filePath = "TestRoomies/src/surveys/group_survey_data.csv";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            if ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 4) {
                    groupPurposeLabel.setText(data[0]);
                    rentLabel.setText(data[1]);
                    utilitiesLabel.setText(data[2]);
                    splitCostLabel.setText(data[3]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

