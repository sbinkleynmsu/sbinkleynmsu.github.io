import java.io.*;
import java.util.Scanner;

public class groupSurvey {
    public static void main(String[] args) {
        try {
            FileWriter csvWriter = new FileWriter("survey_responses.csv");
            BufferedWriter csvBufferedWriter = new BufferedWriter(csvWriter);

            Scanner scanner = new Scanner(System.in);


            // Question 1
            System.out.println("1. How much is the total rent for your shared space?");
            float response1 = scanner.nextFloat();

            // Question 2
            System.out.println("3. Will rent be split equally?");
            String response2 = scanner.nextLine();

            //if rent is split equally add to data how much each perosn owes for rent 

            // Question 3
            float response3 = 0;
            if (response2.equalsIgnoreCase("yes")) {
                System.out.println("3. If not, enter rent amount for each group member");
                response3 = scanner.nextFloat();
            }

            // Question 4
            System.out.println("4. How much are the utilities on average if any?");
            float response4 = scanner.nextFloat();
            //can enter 0

            // Question 5
            System.out.println("5. Will group be splitting costs such as wifi? (yes/no)");
            String response5 = scanner.nextLine();

            // Question 6
            float response6= 0;
            if (response5.equalsIgnoreCase("yes")) {
                System.out.println("7. If yes, how much if wifi per a month? ");
                response6 = scanner.nextFloat();
            }

            // Write responses to CSV
            csvBufferedWriter.write("Total rent," + response1 + "\n");
            csvBufferedWriter.write("Split rent equally," + response2 + "\n");
            csvBufferedWriter.write("Rent not split equally," + response3 + "\n");
            csvBufferedWriter.write("Utilities," + response4 + "\n");
            csvBufferedWriter.write("Wifi?," + response5 + "\n");
            csvBufferedWriter.write("Amount for wifi," + response6 + "\n");

            // Close CSV file
            csvBufferedWriter.close();
            System.out.println("Survey responses saved to groupSurvey_responses.csv.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


