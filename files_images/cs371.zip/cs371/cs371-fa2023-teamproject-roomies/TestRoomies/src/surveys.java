import java.io.*;
import java.util.Scanner;

public class surveys {
    public static void main(String[] args) {
        try {
            FileWriter csvWriter = new FileWriter("survey_responses.csv");
            BufferedWriter csvBufferedWriter = new BufferedWriter(csvWriter);

            Scanner scanner = new Scanner(System.in);

            // Question 1
            System.out.println("1. Do you wish to receive emails and pop-up notifications about upcoming bills and transactions due? (yes/no)");
            String response1 = scanner.nextLine();

            // Question 2
            System.out.println("2. How much do you pay for rent?");
            float response2 = scanner.nextFloat();

            // Question 3
            System.out.println("3. How much do you pay for utilities?");
            float response3 = scanner.nextFloat();

            // Question 4
            System.out.println("4. Do you have car payments? (yes/no)");
            String response4 = scanner.nextLine();

            // Question 5
            float response5 = 0;
            if (response4.equalsIgnoreCase("yes")) {
                System.out.println("5. If yes, how much are your monthly car payments?");
                response5 = scanner.nextFloat();
            }

            // Question 6
            System.out.println("6. Do you have any loans you are currently paying off? (yes/no)");
            String response6 = scanner.nextLine();

            // Question 7
            float response7 = 0;
            if (response6.equalsIgnoreCase("yes")) {
                System.out.println("7. If yes, how much should you be paying per month?");
                response7 = scanner.nextFloat();
            }

            // Question 8
            System.out.println("8. Do you have any debt you are currently paying off? (yes/no)");
            String response8 = scanner.nextLine();

            // Question 9
            float response9 = 0;
            if (response8.equalsIgnoreCase("yes")) {
                System.out.println("9. If yes, how much should you be paying per month?");
                response9 = scanner.nextFloat();
            }

            // Question 10
            System.out.println("10. Do you want to join a group? (Go to the user join page) (yes/no)");
            String response10 = scanner.nextLine();

            // Write responses to CSV
            csvBufferedWriter.write("Receive Email Notifications," + response1 + "\n");
            csvBufferedWriter.write("Rent Payment," + response2 + "\n");
            csvBufferedWriter.write("Utilities Payment," + response3 + "\n");
            csvBufferedWriter.write("Car Payments," + response4 + "\n");
            csvBufferedWriter.write("Car Payment Amount," + response5 + "\n");
            csvBufferedWriter.write("Loans," + response6 + "\n");
            csvBufferedWriter.write("Loan Payment Amount," + response7 + "\n");
            csvBufferedWriter.write("Debt," + response8 + "\n");
            csvBufferedWriter.write("Debt Payment Amount," + response9 + "\n");
            csvBufferedWriter.write("Join a Group," + response10 + "\n");

            // Close CSV file
            csvBufferedWriter.close();
            System.out.println("Survey responses saved to survey_responses.csv.");

            if (response10.equalsIgnoreCase("yes")) {
                System.out.println("You have chosen to join a group. Redirecting to group survey...");
                GroupSurvey.main(args);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class GroupSurvey {
    public static void main(String[] args) {
        try {
            FileWriter csvWriter = new FileWriter("survey_responses.csv", true); // Append to the same CSV
            BufferedWriter csvBufferedWriter = new BufferedWriter(csvWriter);

            Scanner scanner = new Scanner(System.in);

            // Question 1
            System.out.println("1. How much is the total rent for your shared space?");
            float response1 = scanner.nextFloat();

            // Question 2
            System.out.println("3. Will rent be split equally?");
            String response2 = scanner.nextLine();

            //if rent is split equally ad to data how much each perosn owes for rent 

            // Question 3
            float response3 = 0;
            if (response2.equalsIgnoreCase("yes")) {
                System.out.println("3. If not, enter rent amount for each group member");
                response3 = scanner.nextFloat();
            }

            // Question 4
            System.out.println("4. How much are the utilities on average if any?");
            float response4 = scanner.nextFloat();
            //can enter 0

            // Question 5
            System.out.println("5. Will group be splitting costs such as wifi? (yes/no)");
            String response5 = scanner.nextLine();

            // Question 6
            float response6= 0;
            if (response5.equalsIgnoreCase("yes")) {
                System.out.println("7. If yes, how much if wifi per a month? ");
                response6 = scanner.nextFloat();
            }

            // Write responses to CSV
            csvBufferedWriter.write("Total rent," + response1 + "\n");
            csvBufferedWriter.write("Split rent equally," + response2 + "\n");
            csvBufferedWriter.write("Rent not split equally," + response3 + "\n");
            csvBufferedWriter.write("Utilities," + response4 + "\n");
            csvBufferedWriter.write("Wifi?," + response5 + "\n");
            csvBufferedWriter.write("Amount for wifi," + response6 + "\n");
            
            // Close CSV file
            csvBufferedWriter.close();
            System.out.println("Group survey responses saved to survey_responses.csv.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
