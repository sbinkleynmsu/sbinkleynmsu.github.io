import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class GroupMenu {

    public static void joinGroup(Users user){
        Scanner scnr = new Scanner(System.in);
        System.out.println();
        System.out.print("\tPlease enter the group ID you wish to join: ");
        String groupID;
        groupID = Integer.toString(scnr.nextInt());
        List<Group> loadedGroups = Group.loadGroupsFromFile("groupTest.csv");
        while(true){
            for(Group groups : loadedGroups){
                if(groups.getGroupIDNumber() == Integer.parseInt(groupID)){
                    System.out.println("Welcome to the Group!");
                    groups.addMember(user,"groupTest.csv");
                    return;
                }
            }
        }
    }
}
