import java.util.StringJoiner;

public class Users{
    //Private instance variables that contain username, email, password, and user ID
    private String userName;
    private String emailAddress;
    private String passWord;
    private int idNumber;

    public Users(){
        userName = "";
        emailAddress = "";
        passWord = "";
        idNumber = 0;
    }

    //Get and Set methods
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getEmailAddress() {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public String getPassWord() {
        return passWord;
    }
    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
    public int getIdNumber() {
        return idNumber;
    }
    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    /**
     * Method that takes a Users object and puts it into CSV format
     * @return
     */
    public String toCSV(){
        StringJoiner joiner = new StringJoiner(",");
        joiner.add(userName);
        joiner.add(emailAddress);
        joiner.add(passWord);
        joiner.add(Integer.toString(idNumber));
        return joiner.toString();
    }

    /**
     * Method that reads from CSV file and returns a Users object with the given information
     * @param csv
     * @return
     */
    public static Users fromCSV(String csv){
        String[] part = csv.split(",");
        Users user = new Users();
        user.setUserName(part[0]);
        user.setEmailAddress(part[1]);
        user.setPassWord(part[2]);
        user.setIdNumber(Integer.parseInt(part[3]));

        return user;
    }
    
    /**
     * toString method that prints out the user data, just being used for testing at the moment.
     */
    public String toString(){
        System.out.println(userName);
        System.out.println(passWord);
        return "";
    }
}